"""Action space and verifiable safety envelope for VILA.

The action layout follows the AGENS reference code (communication.py):
    a = [modulation, code_rate_index, power_control, encoder, channel_estimator, equalizer, precoder]

Envelope constraints (all explicit, table-driven, independent of any learned model):
  C1  MCS-table consistency (3GPP TS 38.214 Tables 5.1.3.1-1/-2): the code rate must lie inside the
      rate window that the standard tables allow for the selected modulation order.
  C2  Codec admissibility: the convolutional code of the reference implementation only supports
      R in {1/3, 1/2}; the AGENS code silently aliases other indices (rate_list[idx % len]).
  C3  Dynamic transmit-power cap (P_CMAX / network-imposed cap): power offset <= cap.
  C4  Receiver realizability: LMMSE interpolation needs valid channel covariance statistics.
"""
from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from typing import Dict, List, Sequence, Tuple

import numpy as np

MOD_NAMES = ["QPSK", "16QAM", "64QAM", "256QAM"]
MOD_BITS = np.array([2, 4, 6, 8])
RATES = np.array([1 / 3, 1 / 2, 2 / 3, 3 / 4, 0.8])
RATE_NAMES = ["1/3", "1/2", "2/3", "3/4", "4/5"]
POWER_DB = np.array([0.0, 1.0, 2.0, 3.0, 4.0, 6.0, 8.0])
CODE_NAMES = ["LDPC", "Polar", "Conv"]
CE_NAMES = ["LS-NN", "LS-Lin", "LMMSE"]
EQ_NAMES = ["LMMSE", "MF", "ZF"]
PREC_NAMES = ["ZF", "RZF"]

HEAD_NAMES = ["mod", "rate", "power", "code", "ce", "eq", "prec"]
DIMS = (4, 5, 7, 3, 3, 3, 2)
N_RAW = int(np.prod(DIMS))  # 7560
IDX_MOD, IDX_RATE, IDX_POW, IDX_CODE, IDX_CE, IDX_EQ, IDX_PREC = range(7)
VALUE_NAMES = [MOD_NAMES, RATE_NAMES, [f"+{int(p)}dB" for p in POWER_DB], CODE_NAMES, CE_NAMES, EQ_NAMES, PREC_NAMES]

# 3GPP TS 38.214 code-rate windows per modulation order (min / max target code rate over
# MCS Table 1 for QPSK/16QAM/64QAM and Table 2 for 256QAM), with a small tolerance.
MCS_RATE_WINDOW = {
    0: (120 / 1024, 679 / 1024),   # QPSK
    1: (340 / 1024, 658 / 1024),   # 16QAM
    2: (438 / 1024, 948 / 1024),   # 64QAM
    3: (682.5 / 1024, 948 / 1024), # 256QAM
}
RATE_TOL_LOW, RATE_TOL_HIGH = 0.01, 0.03
CONV_RATES = {0, 1}  # indices of 1/3 and 1/2

# Decoding order for prefix-completable constrained decoding.
DECODE_ORDER = (IDX_CODE, IDX_MOD, IDX_RATE, IDX_POW, IDX_CE, IDX_EQ, IDX_PREC)

# Projection distance weights (ordinal dims use |delta index|, categorical dims use mismatch).
ORDINAL = {IDX_MOD: 1.0, IDX_RATE: 0.5, IDX_POW: 0.25}
CATEGORICAL = {IDX_CODE: 1.0, IDX_CE: 0.5, IDX_EQ: 0.5, IDX_PREC: 0.5}

CONSTRAINT_TEXT = {
    "C1": "code rate outside 38.214 MCS window for modulation",
    "C2": "code rate not supported by convolutional codec",
    "C3": "transmit power above cap",
    "C4": "LMMSE estimator without valid covariance",
}


def mcs_ok(mod: int, rate_idx: int) -> bool:
    lo, hi = MCS_RATE_WINDOW[mod]
    r = RATES[rate_idx]
    return (lo - RATE_TOL_LOW) <= r <= (hi + RATE_TOL_HIGH)


def static_tensor() -> np.ndarray:
    """Boolean tensor over DIMS for constraints C1 and C2."""
    F = np.zeros(DIMS, dtype=bool)
    for m, r, c in itertools.product(range(4), range(5), range(3)):
        ok = mcs_ok(m, r) and (c != 2 or r in CONV_RATES)
        F[m, r, :, c, :, :, :] = ok
    return F


_STATIC = static_tensor()


@dataclass(frozen=True)
class EnvelopeState:
    cap_idx: int = 6        # highest admissible POWER_DB index
    cov_valid: bool = True  # covariance statistics available for LMMSE interpolation


def feasible_tensor(e: EnvelopeState) -> np.ndarray:
    F = _STATIC.copy()
    if e.cap_idx < 6:
        F[:, :, e.cap_idx + 1 :, ...] = False
    if not e.cov_valid:
        F[:, :, :, :, 2, :, :] = False
    return F


def violated(a: Sequence[int], e: EnvelopeState) -> List[str]:
    v = []
    if not mcs_ok(a[IDX_MOD], a[IDX_RATE]):
        v.append("C1")
    if a[IDX_CODE] == 2 and a[IDX_RATE] not in CONV_RATES:
        v.append("C2")
    if a[IDX_POW] > e.cap_idx:
        v.append("C3")
    if a[IDX_CE] == 2 and not e.cov_valid:
        v.append("C4")
    return v


def is_feasible(a: Sequence[int], e: EnvelopeState) -> bool:
    return len(violated(a, e)) == 0


def flat_index(a: Sequence[int]) -> int:
    return int(np.ravel_multi_index(tuple(int(x) for x in a), DIMS))


def unflat(i: int) -> Tuple[int, ...]:
    return tuple(int(x) for x in np.unravel_index(i, DIMS))


_ALL = np.array(list(itertools.product(*[range(d) for d in DIMS])), dtype=np.int64)  # (7560, 7)


def all_actions() -> np.ndarray:
    return _ALL


def spectral_eff(a: Sequence[int]) -> float:
    return float(MOD_BITS[a[IDX_MOD]] * RATES[a[IDX_RATE]])


def distance_matrix(a: Sequence[int]) -> np.ndarray:
    """Distance from a to all raw actions."""
    a = np.asarray(a)
    d = np.zeros(len(_ALL))
    for k, w in ORDINAL.items():
        d += w * np.abs(_ALL[:, k] - a[k])
    for k, w in CATEGORICAL.items():
        d += w * (_ALL[:, k] != a[k])
    return d


_SE_ALL = MOD_BITS[_ALL[:, IDX_MOD]] * RATES[_ALL[:, IDX_RATE]]


def project(a: Sequence[int], e: EnvelopeState) -> Tuple[Tuple[int, ...], List[str]]:
    """Nearest-feasible projection; ties broken toward lower spectral efficiency, lower power,
    then lower flat index (deterministic, conservative)."""
    a = tuple(int(x) for x in a)
    v = violated(a, e)
    if not v:
        return a, []
    F = feasible_tensor(e).reshape(-1)
    d = distance_matrix(a)
    d = np.where(F, d, np.inf)
    dmin = d.min()
    cand = np.flatnonzero(np.isclose(d, dmin))
    keys = np.lexsort((cand, _ALL[cand, IDX_POW], _SE_ALL[cand]))
    return unflat(int(cand[keys[0]])), v


def masked_decode(logits: Sequence[np.ndarray], e: EnvelopeState, greedy: bool = True,
                  rng: np.random.Generator | None = None) -> Tuple[Tuple[int, ...], List[np.ndarray]]:
    """Prefix-completable constrained decoding over the 7 actor heads.

    At each step in DECODE_ORDER, values that admit no feasible completion of the current prefix
    receive -inf logits. Returns the action and the masks used (for audit)."""
    F = feasible_tensor(e)
    chosen: Dict[int, int] = {}
    masks = [None] * 7
    for k in DECODE_ORDER:
        # slice F by already-chosen dims, then reduce "any" over all dims except k
        idx = [chosen.get(j, slice(None)) for j in range(7)]
        sub = F[tuple(idx)]
        rem = [j for j in range(7) if j not in chosen]
        pos = rem.index(k)
        axes = tuple(i for i in range(len(rem)) if i != pos)
        mask = sub.any(axis=axes) if axes else sub
        masks[k] = mask
        lg = np.where(mask, np.asarray(logits[k], dtype=float), -np.inf)
        if greedy or rng is None:
            v = int(np.argmax(lg))
        else:
            p = np.exp(lg - lg.max()); p /= p.sum()
            v = int(rng.choice(len(p), p=p))
        chosen[k] = v
    return tuple(chosen[j] for j in range(7)), masks


def envelope_states() -> List[EnvelopeState]:
    return [EnvelopeState(c, b) for c in range(7) for b in (True, False)]


def verify_envelope(n_random_logits: int = 20000, seed: int = 0) -> Dict[str, object]:
    """Exhaustive verification used as a unit test and reported in the paper (E4)."""
    rng = np.random.default_rng(seed)
    out = {"raw_actions": N_RAW, "envelope_states": 0, "projection_checks": 0, "projection_fail": 0,
           "idempotence_fail": 0, "minimality_fail": 0, "decode_checks": 0, "decode_fail": 0,
           "feasible_counts": {}}
    for e in envelope_states():
        out["envelope_states"] += 1
        F = feasible_tensor(e).reshape(-1)
        out["feasible_counts"][f"cap={int(POWER_DB[e.cap_idx])}dB,cov={int(e.cov_valid)}"] = int(F.sum())
        for i, a in enumerate(_ALL):
            p, _ = project(a, e)
            out["projection_checks"] += 1
            if not F[flat_index(p)]:
                out["projection_fail"] += 1
            if F[i] and p != tuple(a):
                out["idempotence_fail"] += 1
            d = np.where(F, distance_matrix(a), np.inf)
            if not np.isclose(distance_matrix(a)[flat_index(p)], d.min()):
                out["minimality_fail"] += 1
            # constrained decoding with one-hot preference for the raw action
            lg = [np.where(np.arange(DIMS[k]) == a[k], 10.0, 0.0) for k in range(7)]
            q, _ = masked_decode(lg, e)
            out["decode_checks"] += 1
            if not F[flat_index(q)]:
                out["decode_fail"] += 1
        for _ in range(n_random_logits // 14):
            lg = [rng.normal(size=d) * rng.uniform(0.1, 20) for d in DIMS]
            q, _ = masked_decode(lg, e, greedy=bool(rng.integers(2)), rng=rng)
            out["decode_checks"] += 1
            if not F[flat_index(q)]:
                out["decode_fail"] += 1
    out["static_feasible"] = int(_STATIC.sum())
    return out


@dataclass
class AuditLog:
    records: List[dict] = field(default_factory=list)

    def log(self, t: int, raw, final, constraints, source: str):
        self.records.append({"t": t, "raw": tuple(int(x) for x in raw), "final": tuple(int(x) for x in final),
                             "constraints": list(constraints), "source": source})


def action_text(a: Sequence[int]) -> str:
    return (f"mod={MOD_NAMES[a[0]]}, rate={RATE_NAMES[a[1]]}, power=+{int(POWER_DB[a[2]])}dB, "
            f"code={CODE_NAMES[a[3]]}, CE={CE_NAMES[a[4]]}, EQ={EQ_NAMES[a[5]]}, prec={PREC_NAMES[a[6]]}")


if __name__ == "__main__":
    import json, time
    t0 = time.time()
    r = verify_envelope()
    r["seconds"] = time.time() - t0
    print(json.dumps(r, indent=1))
