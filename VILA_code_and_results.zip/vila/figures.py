"""Figures and LaTeX tables."""
import json, os, pickle, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from analyze import ci, arr, MAIN, ABL, OUT, FIG

C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
INK = "#0b0b0b"; INK2 = "#52514e"; GRID = "#e4e3df"
plt.rcParams.update({"font.family": "serif", "font.size": 7.5, "axes.titlesize": 8, "axes.labelsize": 7.5, "legend.fontsize": 6.5,
                     "xtick.labelsize": 6.5, "ytick.labelsize": 6.5, "axes.edgecolor": INK2, "axes.linewidth": 0.6,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.labelcolor": INK, "text.color": INK,
                     "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.5, "axes.axisbelow": True,
                     "pdf.fonttype": 42, "savefig.bbox": "tight", "savefig.pad_inches": 0.02})
COLW = 3.45
SHORT = {"AGENS-Open": "Open", "AGENS-Open+Env": "Open+Env", "AGENS-OLLA": "OLLA", "AGENS-Fixed": "Fixed", "AGENS-StatOnly": "StatOnly",
         "AGENS-Stat+Rule": "Stat+Rule", "AGENS-SemOnly": "SemOnly", "Greedy-Replan": "Greedy", "Beam-Replan": "Beam", "VILA": "VILA",
         "VILA-noMem": "VILA-noMem"}


def fig_tradeoff(S):
    R = S["results"]
    fig, axs = plt.subplots(1, 3, figsize=(7.1, 2.0), sharey=False)
    ms = ["AGENS-Open+Env", "AGENS-OLLA", "AGENS-Fixed", "AGENS-StatOnly", "AGENS-SemOnly", "Greedy-Replan", "VILA", "VILA-noMem"]
    for ax, Sx in zip(axs, "ABC"):
        for j, m in enumerate(ms):
            x, xe = ci(arr(R, Sx, m, "gen100") + arr(R, Sx, m, "evals100") * 0)
            if m.startswith("Greedy"):
                x, xe = ci(arr(R, Sx, m, "replan100"))
            y, ye = ci(arr(R, Sx, m, "cum_regret"))
            ax.errorbar(max(x, 0.5), y, yerr=ye, fmt="o", ms=4, color=C[j % 8], mec="white", mew=0.6, elinewidth=0.8, capsize=1.5,
                        label=SHORT[m])
        ax.set_xscale("log"); ax.set_xlim(1, 200)
        ax.set_title(f"Test set {Sx}"); ax.set_xlabel("Generator invocations / 100 cycles")
    axs[0].set_ylabel("Cumulative regret (300 cycles)")
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, ncol=8, loc="upper center", bbox_to_anchor=(0.5, 1.12), frameon=False, handletextpad=0.2, columnspacing=0.9)
    fig.savefig(os.path.join(FIG, "fig_tradeoff.pdf")); plt.close(fig)


def fig_intent_aligned(aligned):
    fig, ax = plt.subplots(figsize=(COLW, 1.9))
    lags = np.arange(-3, 21)
    for j, (m, lab) in enumerate([("VILA", "VILA"), ("AGENS-Fixed", "AGENS-Fixed"), ("AGENS-Open+Env", "AGENS-Open+Env"), ("AGENS-StatOnly", "AGENS-StatOnly")]):
        Y = np.array(aligned[m]); mu = Y.mean(0); h = 1.96 * Y.std(0, ddof=1) / np.sqrt(len(Y))
        ax.plot(lags, mu, color=C[[6, 2, 0, 3][j]], lw=1.4, label=lab)
        ax.fill_between(lags, mu - h, mu + h, color=C[[6, 2, 0, 3][j]], alpha=0.15, lw=0)
    ax.axvline(0, color=INK2, lw=0.6, ls="--")
    ax.set_xlabel("Cycles relative to intent change"); ax.set_ylabel("Per-cycle regret")
    ax.legend(frameon=False, ncol=2, loc="upper right")
    fig.savefig(os.path.join(FIG, "fig_intent_aligned.pdf")); plt.close(fig)


def fig_trigger(summ):
    T = summ["trig"]
    ms = [("AGENS-StatOnly", "StatOnly"), ("AGENS-SemOnly", "SemOnly"), ("AGENS-Stat+Rule", "Stat+Rule"), ("VILA", "Fusion (VILA)")]
    fig, axs = plt.subplots(1, 2, figsize=(7.1, 1.9), gridspec_kw={"width_ratios": [1, 1.5]})
    w = 0.2; x = np.arange(3)
    for j, (m, lab) in enumerate(ms):
        v = [T[m]["AB"][k] for k in ("precision", "recall", "f1")]
        axs[0].bar(x + (j - 1.5) * w, v, w * 0.9, color=C[j], label=lab)
    axs[0].set_xticks(x); axs[0].set_xticklabels(["Precision", "Recall", "$F_1$"]); axs[0].set_ylim(0, 1.05)
    axs[0].set_title("Event-level detection, sets A+B"); axs[0].legend(frameon=False, fontsize=6, ncol=2, loc="lower left")
    keys = [("regime", "Regime"), ("blockage", "Blockage"), ("intent", "Intent"), ("neg_transient", "Transient\n(neg.)"), ("neg_restate", "Restate\n(neg.)")]
    x = np.arange(len(keys))
    for j, (m, lab) in enumerate(ms):
        v = [T[m]["types_AB"][k] if k != "neg_restate" else T[m]["types_C"][k] for k, _ in keys]
        axs[1].bar(x + (j - 1.5) * w, v, w * 0.9, color=C[j])
    axs[1].set_xticks(x); axs[1].set_xticklabels([k for _, k in keys]); axs[1].set_ylim(0, 1.05)
    axs[1].set_title("Fraction of events with a trigger (positives) / false firing (negatives)")
    fig.tight_layout(w_pad=1.0)
    fig.savefig(os.path.join(FIG, "fig_trigger.pdf")); plt.close(fig)


def fig_sens(e25):
    sens = e25["sens"]; fh = sorted({s["fh"] for s in sens}); ft = sorted({s["ft"] for s in sens})
    M = np.array([[next(s["f1"] for s in sens if s["fh"] == a and s["ft"] == b) for b in ft] for a in fh])
    fig, ax = plt.subplots(figsize=(COLW * 0.62, 1.7))
    im = ax.imshow(M, cmap="Blues", vmin=M.min() - 0.05, vmax=1.0, origin="lower")
    for i in range(len(fh)):
        for j in range(len(ft)):
            ax.text(j, i, f"{M[i,j]:.2f}", ha="center", va="center", fontsize=5.5, color="white" if M[i, j] > (M.min() + 1) / 2 + 0.02 else INK)
    ax.set_xticks(range(len(ft))); ax.set_xticklabels([f"{v:.1f}" for v in ft]); ax.set_yticks(range(len(fh))); ax.set_yticklabels([f"{v:.1f}" for v in fh])
    ax.set_xlabel(r"$\tau$ scaling"); ax.set_ylabel(r"$h$ scaling"); ax.grid(False)
    fig.savefig(os.path.join(FIG, "fig_sens.pdf")); plt.close(fig)


def fig_latency(L):
    Ds = [0, 2, 6, 33]
    fig, axs = plt.subplots(1, 2, figsize=(7.1, 1.85))
    for ax, Sx in zip(axs, "AB"):
        for j, (m, lab) in enumerate([("AGENS-Open+Env", "AGENS-Open+Env"), ("AGENS-Fixed", "AGENS-Fixed"), ("VILA", "VILA"), ("VILA-noMem", "VILA-noMem")]):
            mu = []; h = []
            for D in Ds:
                v = np.array([L[Sx][s][f"{m}|{D}"]["cum_regret"] for s in sorted(L[Sx])]); a, b = ci(v); mu.append(a); h.append(b)
            ax.errorbar(np.arange(4) + (j - 1.5) * 0.06, mu, yerr=h, marker="o", ms=3.5, lw=1.3, capsize=1.5, color=C[[0, 2, 6, 1][j]], label=lab)
        ax.set_xticks(range(4)); ax.set_xticklabels(["0 (ideal)", "2 (10 ms)", "6 (30 ms)", "33 (167 ms)"])
        ax.set_xlabel("Generator latency $D$ in cycles (time)"); ax.set_title(f"Test set {Sx}")
    axs[0].set_ylabel("Cumulative regret"); axs[0].legend(frameon=False, ncol=2)
    fig.tight_layout(w_pad=1.0)
    fig.savefig(os.path.join(FIG, "fig_latency.pdf")); plt.close(fig)


def fig_probe(e25):
    P = e25["probe"]; Bs = sorted({p["budget"] for p in P})
    fig, ax = plt.subplots(figsize=(COLW * 0.62, 1.7))
    keys = [("n_changes", "# intent changes"), ("prev_intent", "previous intent"), ("last_switch", "last switch"), ("top_failure", "top failure")]
    for j, (k, lab) in enumerate(keys):
        acc = [np.mean([p[k] for p in P if p["budget"] == B]) for B in Bs]
        ax.plot(range(len(Bs)), np.array(acc) - 0.015 * j * (np.array(acc) > 0.99), marker="osD^"[j], ms=3, lw=1.1, ls=["-", "--", "-", ":"][j], color=C[j], label=lab)
    ax.set_xticks(range(len(Bs))); ax.set_xticklabels([str(b) if b < 10 ** 5 else "$\\infty$" for b in Bs])
    ax.set_xlabel("Summary budget $B_s$ [tokens]"); ax.set_ylabel("Probe accuracy"); ax.set_ylim(0, 1.05)
    ax.legend(frameon=False, fontsize=5.5, loc="lower right")
    fig.savefig(os.path.join(FIG, "fig_probe.pdf")); plt.close(fig)


def fmt(v, d=1):
    m, h = v
    if not np.isfinite(h):
        return f"{m:.{d}f}"
    return f"{m:.{d}f}\\,$\\pm$\\,{h:.{d}f}"


def tables(summ):
    M = summ["main"]; T = summ["tests"]
    rows = []
    order = ["AGENS-Open", "AGENS-Open+Env", "AGENS-OLLA", "AGENS-Fixed", "AGENS-StatOnly", "AGENS-Stat+Rule", "AGENS-SemOnly", "Greedy-Replan", "Beam-Replan", "VILA", "Oracle"]
    for m in order:
        cells = []
        for Sx in "ABC":
            r = M[Sx][m]
            star = ""
            if m in T[Sx]:
                star = "$^{*}$" if T[Sx][m]["p_holm"] < 0.05 else ""
            cells += [fmt(r["cum_regret"]) + star, f"{100*r['sat'][0]:.1f}", f"{r['switch100'][0]:.1f}", f"{r['replan100'][0]:.1f}"]
        name = "\\textbf{VILA}" if m == "VILA" else m
        rows.append(name + " & " + " & ".join(cells) + " \\\\")
    open(os.path.join(FIG, "..", "tab_main.tex"), "w").write("\n".join(rows))
    rows = []
    for m in ABL:
        cells = []
        for Sx in "ABC":
            r = M[Sx][m]
            star = ""
            if m != "VILA" and m in T[Sx + "_abl"]:
                star = "$^{*}$" if T[Sx + "_abl"][m]["p_holm"] < 0.05 else ""
            cells += [fmt(r["cum_regret"]) + star, f"{100*r['sat'][0]:.1f}", f"{r['switch100'][0]:.1f}", f"{100*r['viol_rate'][0]:.2f}"]
        rows.append(m + " & " + " & ".join(cells) + " \\\\")
    open(os.path.join(FIG, "..", "tab_abl.tex"), "w").write("\n".join(rows))


def aligned_intent_regret():
    import run_experiments as RE
    from agent import Method, run_episode, cycle_reference
    from scenarios import make_spec, Episode
    models = RE.load_models()
    ms = {m.name: m for m in RE.METHODS}
    out = {k: [] for k in ("VILA", "AGENS-Fixed", "AGENS-Open+Env", "AGENS-StatOnly")}
    for s in range(20):
        sd = RE.SEED_BASE["A"] + s
        spec = make_spec("A", RE.T_EP, np.random.default_rng(sd)); ep = Episode(spec, sd)
        refs = [cycle_reference(c) for c in ep.cycles]
        for k in out:
            log = run_episode(ep, ms[k], models, refs)
            for e in spec.events:
                if e.kind == "intent" and e.t >= 3 and e.t + 21 <= RE.T_EP:
                    out[k].append(log["regret"][int(e.t) - 3:int(e.t) + 21])
    return out


if __name__ == "__main__":
    S = pickle.load(open(os.path.join(OUT, "exp_A_B_C.pkl"), "rb"))
    summ = json.load(open(os.path.join(OUT, "summary.json")))
    what = sys.argv[1:] or ["main"]
    if "main" in what:
        fig_tradeoff(S); fig_trigger(summ); tables(summ)
        al_path = os.path.join(OUT, "aligned_intent.pkl")
        if not os.path.exists(al_path):
            pickle.dump(aligned_intent_regret(), open(al_path, "wb"))
        fig_intent_aligned(pickle.load(open(al_path, "rb")))
    if "e25" in what:
        e25 = json.load(open(os.path.join(OUT, "e2_e5.json"))); fig_sens(e25); fig_probe(e25)
    if "lat" in what:
        fig_latency(pickle.load(open(os.path.join(OUT, "exp_latency.pkl"), "rb")))
    print("figures done")
