"""Statistical change detectors (two-sided CUSUM, BOCPD) and the fused replanning trigger."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np


@dataclass
class CUSUM:
    """Two-sided CUSUM on standardised KPI streams with warm-up re-referencing after each reset."""
    k: float = 0.5
    h: float = 5.0
    sigma: np.ndarray = field(default_factory=lambda: np.ones(3))
    warmup: int = 2
    track: float = 0.02     # forgetting factor of the reference mean (adaptive drift tolerance)
    zclip: float = 4.0      # winsorisation of standardised innovations
    n: int = 0
    mu: Optional[np.ndarray] = None
    sp: np.ndarray = field(default_factory=lambda: np.zeros(3))
    sn: np.ndarray = field(default_factory=lambda: np.zeros(3))

    def reset(self):
        self.n = 0; self.mu = None; self.sp = np.zeros(3); self.sn = np.zeros(3)

    def update(self, x: np.ndarray) -> float:
        x = np.asarray(x, dtype=float)
        self.n += 1
        if self.mu is None:
            self.mu = x.copy(); return 0.0
        if self.n <= self.warmup:
            self.mu = self.mu + (x - self.mu) / self.n; return 0.0
        z = np.clip((x - self.mu) / self.sigma, -self.zclip, self.zclip)
        self.sp = np.maximum(0, self.sp + z - self.k)
        self.sn = np.maximum(0, self.sn - z - self.k)
        self.mu = self.mu + self.track * (x - self.mu)   # reference tracking
        return float(np.max(np.maximum(self.sp, self.sn)))


@dataclass
class BOCPD:
    """Bayesian online change-point detection (Adams & MacKay, 2007), Gaussian likelihood with
    known variance and conjugate Normal prior on the mean; returns P(run length <= r0)."""
    hazard: float = 1 / 100
    var: float = 1.0
    prior_var: float = 4.0
    rmax: int = 120
    r0: int = 2
    logR: Optional[np.ndarray] = None
    mu: Optional[np.ndarray] = None
    v: Optional[np.ndarray] = None
    mu0: Optional[float] = None

    def reset(self):
        self.logR = None

    def update(self, x: float) -> float:
        if self.logR is None:
            self.mu0 = x; self.logR = np.array([0.0]); self.mu = np.array([x]); self.v = np.array([self.prior_var]); return 0.0
        pv = self.v + self.var
        ll = -0.5 * np.log(2 * np.pi * pv) - 0.5 * (x - self.mu) ** 2 / pv
        grow = self.logR + ll + np.log(1 - self.hazard)
        cp = np.logaddexp.reduce(self.logR + ll + np.log(self.hazard))
        logR = np.concatenate([[cp], grow])
        logR -= np.logaddexp.reduce(logR)
        # posterior update of each run's mean
        v_new = 1 / (1 / self.v + 1 / self.var)
        mu_new = v_new * (self.mu / self.v + x / self.var)
        mu = np.concatenate([[self.mu0], mu_new]); v = np.concatenate([[self.prior_var], v_new])
        if len(logR) > self.rmax:
            logR = logR[: self.rmax]; mu = mu[: self.rmax]; v = v[: self.rmax]
            logR -= np.logaddexp.reduce(logR)
        self.logR, self.mu, self.v = logR, mu, v
        return float(np.exp(np.logaddexp.reduce(logR[: self.r0 + 1])))


@dataclass
class FusionTrigger:
    """g(s, Lambda, c) = sigmoid(w . phi + b); fires if p > tau and outside the cooldown."""
    w: np.ndarray = field(default_factory=lambda: np.zeros(4))
    b: float = 0.0
    tau: float = 0.5
    cooldown: int = 3
    last_fire: int = -10 ** 9

    @staticmethod
    def phi(s: float, lam_norm: float, cp: float) -> np.ndarray:
        s = float(np.clip(s, 1e-4, 1 - 1e-4))
        return np.array([np.log(s / (1 - s)), lam_norm, cp, s * lam_norm])

    def prob(self, s, lam_norm, cp) -> float:
        z = float(self.w @ self.phi(s, lam_norm, cp) + self.b)
        return 1 / (1 + np.exp(-z))

    def in_cooldown(self, t: int) -> bool:
        return t - self.last_fire <= self.cooldown

    def fire(self, t: int):
        self.last_fire = t


def event_metrics(trig_t: List[int], events: List[int], T: int, window: int = 5, start: int = 1):
    """Event-level precision/recall/F1, per-cycle false-trigger rate, and detection delays."""
    trig = sorted(set(int(t) for t in trig_t if t >= start))
    covered = np.zeros(T, dtype=bool)
    for e in events:
        covered[e: min(T, e + window + 1)] = True
    tp_trig = sum(1 for t in trig if covered[t])
    detected, delays = 0, []
    for e in events:
        hits = [t - e for t in trig if e <= t <= e + window]
        if hits:
            detected += 1; delays.append(min(hits))
    n_neg = int((~covered[start:]).sum())
    fp = sum(1 for t in trig if not covered[t])
    prec = tp_trig / len(trig) if trig else (1.0 if not events else 0.0)
    rec = detected / len(events) if events else 1.0
    f1 = 2 * prec * rec / (prec + rec) if prec + rec > 0 else 0.0
    return {"precision": prec, "recall": rec, "f1": f1, "fpr": fp / max(n_neg, 1), "delay": float(np.mean(delays)) if delays else np.nan,
            "n_trig": len(trig), "tp": tp_trig, "fp": fp, "detected": detected, "n_events": len(events)}
