"""Closed-loop VILA agent and all baselines, run over a pre-computed Episode."""
from __future__ import annotations

import time
from dataclasses import dataclass, field, replace
from typing import Dict, List, Optional

import numpy as np

from actions import (DIMS, IDX_CE, IDX_CODE, IDX_MOD, IDX_POW, IDX_RATE, CONV_RATES, AuditLog, EnvelopeState,
                     feasible_tensor, flat_index, is_feasible, masked_decode, mcs_ok, project, unflat, violated,
                     all_actions, POWER_DB, action_text, CONSTRAINT_TEXT)
from linksim import kpi_tables, M_SLOTS, INTENT_NAMES
from memory import SemanticMemory, Tuple_, n_tokens
from models import N_REFL_FEAT, CAUSES, js_div
from scenarios import POSITIVE, Episode
from triggers import BOCPD, CUSUM, FusionTrigger

_FCACHE: Dict[tuple, np.ndarray] = {}
DEFAULT_ACTION = (0, 0, 0, 0, 0, 0, 0)


def feas_flat(e: EnvelopeState) -> np.ndarray:
    k = (e.cap_idx, e.cov_valid)
    if k not in _FCACHE:
        _FCACHE[k] = feasible_tensor(e).reshape(-1)
    return _FCACHE[k]


def unguarded_execution(a, e: EnvelopeState):
    """What the reference stack does with an inadmissible configuration (no envelope)."""
    a = list(a)
    if not mcs_ok(a[IDX_MOD], a[IDX_RATE]):
        a[IDX_MOD], a[IDX_RATE] = 0, 0                       # MCS cannot be signalled -> fallback MCS
    if a[IDX_CODE] == 2 and a[IDX_RATE] not in CONV_RATES:
        a[IDX_RATE] = a[IDX_RATE] % 2                        # silent aliasing as in AGENS code
    if a[IDX_POW] > e.cap_idx:
        a[IDX_POW] = e.cap_idx                               # PA clips at cap
    return tuple(a)                                          # C4: LMMSE runs with stale covariance


# ----------------------------------------------------------------------------- per-cycle references
def cycle_reference(c) -> dict:
    F = feas_flat(c.env)
    r = c.tables["reward"].reshape(-1); ber = c.tables["ber"].reshape(-1); rate = c.tables["rate"].reshape(-1)
    pw = np.broadcast_to(POWER_DB[None, None, :, None, None, None, None], DIMS).reshape(-1)
    rf = np.where(F, r, -np.inf)
    ref = {"oracle": float(rf.max()), "oracle_a": int(rf.argmax())}
    ok2 = F & (ber <= 1e-2)
    bmin = float(ber[F].min())
    ref["G"] = float(rate[ok2].max()) if ok2.any() else 0.0
    ref["Bmin"] = bmin
    ref["Pmin"] = float(pw[ok2].min()) if ok2.any() else None
    b4 = max(1e-4, 10 * bmin); ok4 = F & (ber <= b4)
    ref["P4"] = float(pw[ok4].min()) if ok4.any() else 8.0
    return ref


def satisfied(intent, ber, rate, pwr, rew, ref) -> bool:
    if intent == 0:
        return ber <= 1e-2 and rate >= 0.85 * ref["G"]
    if intent == 1:
        return ber <= max(1e-5, 10 * ref["Bmin"])
    if intent == 2:
        if ref["Pmin"] is None:
            return ber <= 2 * ref["Bmin"]
        return ber <= 1e-2 and pwr <= ref["Pmin"] + 1.0
    if intent == 3:
        return rew >= ref["oracle"] - 0.05
    return ber <= max(1e-4, 10 * ref["Bmin"]) and pwr <= ref["P4"] + 1.0


# ----------------------------------------------------------------------------- search baselines
def nominal_reward(c_prev, intent):
    """Model-based evaluation used by Greedy/Beam: link simulated on the last reported channel
    with the reported SNR and no knowledge of the (hidden) interference."""
    cs = replace(c_prev.cs, interf_db=-30.0, snr_db=float(c_prev.feat[24] * 10 - 10 * np.log10(np.mean(np.abs(c_prev.cs.H) ** 2) + 1e-12)))
    return kpi_tables(cs, intent)["reward"].reshape(-1)


MODULE_ORDER = (IDX_CODE, IDX_MOD, IDX_RATE, IDX_POW, IDX_CE, 5, 6)


def greedy_search(rnom, F, start=DEFAULT_ACTION, beam=1):
    beams = [(float(rnom[flat_index(start)]) if F[flat_index(start)] else -np.inf, tuple(start))]
    evals = 0
    for k in MODULE_ORDER:
        cand = {}
        for _, a in beams:
            for v in range(DIMS[k]):
                b = list(a); b[k] = v; b = tuple(b); i = flat_index(b); evals += 1
                if F[i]:
                    cand[b] = float(rnom[i])
        if cand:
            beams = sorted(((r, a) for a, r in cand.items()), reverse=True)[:beam]
    return beams[0][1], evals


# ----------------------------------------------------------------------------- reflection features
def reflection_features(mem: SemanticMemory, feat_rep, last: Optional[Tuple_], text_changed: bool, probs,
                        since_replan: int, persist: int, prev_dsnr: float) -> np.ndarray:
    x = np.zeros(N_REFL_FEAT, dtype=np.float32)
    x[0] = float(text_changed)
    x[1] = 5 * js_div(probs, mem.last_intent_probs) if mem.last_intent_probs is not None else 0.0
    snr = feat_rep[24] * 10
    x[2] = (snr - mem.ewma_snr) / 10 if mem.ewma_snr is not None else 0.0
    if mem.regime_feat is not None:
        d = np.abs(feat_rep - mem.regime_feat)
        x[3:7] = d[25:29]
        x[7] = float(np.mean(d[:24]))
    if last is not None:
        x[8] = last.frac; x[9] = np.log10(last.ber + 1e-7) / 7 + 1; x[10] = last.frac - mem.ewma_frac
    x[11] = min(persist, 5) / 5
    # x[12], x[14] (cycles since re-plan, memory-epoch age) are deliberately left at zero: in event-driven
    # training rollouts they leak the behaviour policy's re-planning times into the labels.
    x[13] = prev_dsnr / 10
    fr = [e.frac for e in list(mem.buf)[-3:]]
    x[15] = float(np.mean(fr)) if fr else 0.0
    return x


# ----------------------------------------------------------------------------- method configuration
@dataclass
class Method:
    name: str
    generator: str = "mem"          # mem | nomem | greedy | beam | oracle
    trigger: str = "fusion"         # every | fixed | stat | sem | fusion | statrule | events
    envelope: str = "mask"          # mask | posthoc | project | none
    period: int = 10
    cooldown: int = 3
    W: int = 4
    summary_budget: int = 150
    gated: bool = False
    olla: bool = False
    invalidate: bool = True
    latency: int = 0                # generator inference latency in cycles (decision takes effect after D cycles)


@dataclass
class Models:
    intent: object
    pol_mem: object
    pol_nomem: object
    refl: object
    calib: dict          # detector parameters and fusion weights per trigger family
    W_train: int = 4


def build_policy_input(feat, probs, env: EnvelopeState, memf=None):
    parts = [feat, probs.astype(np.float32), np.array([env.cap_idx / 6, float(env.cov_valid)], dtype=np.float32)]
    if memf is not None:
        parts.append(memf)
    return np.concatenate(parts).astype(np.float32)


def decide(method: Method, models: Models, x, env, F):
    net = models.pol_mem if method.generator == "mem" else models.pol_nomem
    lg = net.logits_np(x)
    raw = tuple(int(np.argmax(l)) for l in lg)
    if method.envelope == "mask":
        a, _ = masked_decode(lg, env)
        return raw, a, "masked"
    if method.envelope == "posthoc":
        A = all_actions()
        score = sum(lg[k][A[:, k]] - np.logaddexp.reduce(lg[k]) for k in range(7))
        score = np.where(F, score, -np.inf)
        return raw, unflat(int(np.argmax(score))), "posthoc"
    if method.envelope == "project":
        a, _ = project(raw, env)
        return raw, a, "project"
    return raw, raw, "none"


def run_episode(ep: Episode, method: Method, models: Models, refs: List[dict], audit: Optional[AuditLog] = None,
                record_text: bool = False) -> dict:
    T = len(ep.cycles)
    cal = models.calib
    mem = SemanticMemory(W=method.W, summary_budget=method.summary_budget)
    fam = {"stat": "stat", "sem": "sem", "fusion": "fusion", "statrule": "stat"}.get(method.trigger, "fusion")
    cus = CUSUM(k=cal["cusum_k"], h=cal["cusum_h"], sigma=np.array(cal["kpi_sigma"]), track=cal.get("cusum_track", 0.02))
    bo = BOCPD(hazard=cal["bocpd_hazard"], var=cal["bocpd_var"])
    trig = FusionTrigger(w=np.array(cal[fam]["w"]), b=cal[fam]["b"], tau=cal[fam]["tau"], cooldown=method.cooldown)
    events_pos = sorted({int(e.t) for e in ep.spec.events if e.kind in POSITIVE})
    _r = np.random.default_rng(len(ep.cycles) * 7919 + len(events_pos))
    noisy_fire = {e + int(_r.integers(1, 6)) for e in events_pos} | {int(t) for t in np.flatnonzero(_r.uniform(size=T) < 0.05)}
    gt_cause = {}
    for e in ep.spec.events:
        if e.kind == "intent":
            gt_cause[int(e.t)] = "intent"
        elif e.kind in ("regime", "blockage"):
            gt_cause[int(e.t) + 1] = e.kind
    a_prev = None; prev_text = None; since_replan = 0; persist = 0; prev_dsnr = 0.0
    olla = 0.0
    log = {k: [] for k in ["reward", "oracle", "regret", "sat", "switch", "trigger", "replan", "violation", "projected",
                           "refl_called", "s", "p", "lam", "cp", "ctx_tokens", "cause", "intent", "evals", "gen_calls", "raw_infeasible", "x_kpi"]}
    XR = []
    texts = []
    last: Optional[Tuple_] = None
    pending = []                     # in-flight decisions (apply_time, action)
    last_exec = None
    for t in range(T):
        while pending and pending[0][0] <= t:
            a_prev = pending.pop(0)[1]
        c = ep.cycles[t]; cp_ = ep.cycles[t - 1] if t > 0 else ep.cycles[0]
        feat = cp_.feat.copy()
        probs = models.intent.probs(c.text)
        text_changed = (prev_text is not None and c.text != prev_text)
        F = feas_flat(c.env)
        # ---------------- statistical detectors (KPI of t-1)
        lam = cpp = 0.0
        if last is not None:
            xk = np.array([np.log10(last.ber + 1e-6), last.rate, feat[24] * 10])
            lam = cus.update(xk) / cus.h
            cpp = bo.update(feat[24] * 10)
        # ---------------- reflection (semantic deviation score)
        s = 0.0; cause_p = np.zeros(len(CAUSES)); cause_p[0] = 1; refl_called = False
        dsnr = (feat[24] * 10 - mem.ewma_snr) if mem.ewma_snr is not None else 0.0
        persist = persist + 1 if dsnr < -4 else 0
        uses_refl = method.trigger in ("sem", "fusion") or method.generator in ("mem",)
        xr = reflection_features(mem, feat, last, text_changed, probs, since_replan, persist, prev_dsnr)
        XR.append(xr)
        if uses_refl and t > 0 and models.refl is not None:
            screen = (not method.gated) or text_changed or abs(dsnr) > 3 or (last is not None and last.frac > 0) \
                     or float(np.max(xr[3:8])) > 0.15 or lam > 0.5
            if screen:
                s, cause_p = models.refl.predict(xr); refl_called = True
        prev_dsnr = dsnr
        # ---------------- trigger
        p = 0.0
        if t == 0:
            fire = True
        elif method.trigger == "every":
            fire = True
        elif method.trigger == "fixed":
            fire = (t % method.period == 0)
        elif method.trigger == "events":
            fire = any(t == e or t == e + 1 for e in events_pos)
        elif method.trigger == "events_noisy":
            fire = (t in noisy_fire)
        else:
            if fam == "sem":
                p = trig.prob(s, 0.0, 0.0) if True else 0.0
                p = 1 / (1 + np.exp(-(trig.w[0] * np.log(np.clip(s, 1e-4, 1 - 1e-4) / (1 - np.clip(s, 1e-4, 1 - 1e-4))) + trig.b)))
            elif fam == "stat":
                p = 1 / (1 + np.exp(-(trig.w[1] * lam + trig.w[2] * cpp + trig.b)))
            else:
                p = trig.prob(s, lam, cpp)
            fire = p > trig.tau
            if method.trigger == "statrule" and text_changed:
                fire = True
            if fire and trig.in_cooldown(t):
                fire = False
            if fire and pending:
                fire = False             # a decision is still in flight
        replan = fire
        cause = CAUSES[int(np.argmax(cause_p))] if refl_called else "none"
        if models.refl is None and method.trigger in ("events", "events_noisy"):
            cause = next((gt_cause[u] for u in range(t - 5, t + 1) if u in gt_cause), "none")
        evals = 0; gen_call = 0
        if replan:
            trig.fire(t)
            if t > 0 and method.trigger not in ("every", "fixed"):
                if method.invalidate and cause in ("regime", "blockage"):
                    mem.new_epoch(t, cause)
                elif cause == "intent":
                    mem.switches.append([t, "intent"])
            cus.reset(); bo.reset()
            if method.generator in ("mem", "nomem"):
                f_in = feat.copy()
                if method.olla:
                    f_in[24] -= olla / 10
                memf = mem.features() if method.generator == "mem" else None
                x = build_policy_input(f_in, probs, c.env, memf)
                raw, a, how = decide(method, models, x, c.env, F)
                gen_call = 1
            elif method.generator in ("greedy", "beam"):
                rnom = nominal_reward(cp_, int(np.argmax(probs)) if probs.max() > 0.5 else 3)
                a, evals = greedy_search(rnom, F, beam=1 if method.generator == "greedy" else 2)
                raw = a; how = "search"
            else:  # oracle
                a = unflat(refs[t]["oracle_a"]); raw = a; how = "oracle"
            since_replan = 0
            if method.latency > 0:
                pending.append((t + method.latency, a))
                if a_prev is None:
                    a_prev = DEFAULT_ACTION
                raw = a_prev; a = a_prev; how = "hold"
        else:
            raw = a_prev; a = a_prev; how = "hold"
            since_replan += 1
        viol = violated(raw, c.env)
        projected = False
        if method.envelope == "none":
            a_exec = unguarded_execution(a, c.env)
        else:
            if not is_feasible(a, c.env):         # held action invalidated by a new envelope state
                a, _ = project(a, c.env); projected = True
            a_exec = a
            assert F[flat_index(a_exec)], "envelope breach"
        if audit is not None and (viol or projected):
            audit.log(t, raw, a_exec, viol or violated(a_prev or raw, c.env), how)
        i = flat_index(a_exec)
        tb = c.tables
        ber = float(tb["ber"].reshape(-1)[i]); rate = float(tb["rate"].reshape(-1)[i]); rew = float(tb["reward"].reshape(-1)[i])
        pwr = float(POWER_DB[a_exec[IDX_POW]])
        log["reward"].append(rew); log["oracle"].append(refs[t]["oracle"]); log["regret"].append(refs[t]["oracle"] - rew)
        log["sat"].append(satisfied(c.intent, ber, rate, pwr, rew, refs[t]))
        log["switch"].append(int(last_exec is not None and a_exec != last_exec))
        log["trigger"].append(int(replan)); log["replan"].append(int(replan))
        log["raw_infeasible"].append(int(bool(viol) and replan and how not in ("hold",)))
        log["violation"].append(int(bool(viol) and method.envelope == "none"))
        log["projected"].append(int(projected)); log["refl_called"].append(int(refl_called)); log["s"].append(s)
        log["p"].append(p); log["lam"].append(lam); log["cp"].append(cpp); log["cause"].append(cause); log["intent"].append(c.intent)
        log["evals"].append(evals); log["gen_calls"].append(gen_call)
        log["x_kpi"].append(xk if last is not None else np.full(3, np.nan))
        if method.generator == "mem" or method.trigger in ("sem", "fusion"):
            ctx = mem.context(c.text, f"P_max=+{int(POWER_DB[c.env.cap_idx])}dB, cov_valid={int(c.env.cov_valid)}") if replan else None
            log["ctx_tokens"].append(n_tokens(ctx) if ctx is not None else 0)
            if record_text and ctx is not None:
                texts.append((t, ctx))
        else:
            log["ctx_tokens"].append(0)
        # ---------------- observe KPI of t, update memory
        frac = float(tb["frac"].reshape(-1)[i]); ber_obs = float(tb["ber_obs"].reshape(-1)[i]); rate_obs = float(tb["rate_obs"].reshape(-1)[i])
        if method.olla:
            nf = frac * M_SLOTS
            olla = float(np.clip(olla + 0.5 * nf - 0.5 * (0.1 / 0.9) * (M_SLOTS - nf), -3, 15))
        last = Tuple_(t, a_exec, ber_obs, frac, rate_obs, float(c.feat[24] * 10), c.intent, mem.epoch)
        mem.push(last)
        mem.update_regime_feat(c.feat)
        mem.note_intent(int(np.argmax(probs)), t)
        mem.last_intent_probs = probs
        prev_text = c.text; a_prev = a_exec; last_exec = a_exec
    out = {k: np.array(v) for k, v in log.items() if k != "cause"}
    out["xr"] = np.array(XR)
    out["cause"] = log["cause"]; out["events_pos"] = events_pos; out["texts"] = texts
    out["mem_summary"] = mem.summary_text(); out["mem"] = mem
    return out
