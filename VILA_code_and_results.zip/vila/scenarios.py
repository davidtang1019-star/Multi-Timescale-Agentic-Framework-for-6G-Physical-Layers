"""Episode / event generation for training, calibration and test sets A, B, C."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np

from actions import EnvelopeState
from linksim import (M_SLOTS, NR, NS, NSUB, REGIMES, TRAIN_REGIMES, UNSEEN_REGIMES, Channel, CycleState, Regime,
                     csi_features, kpi_tables)

# Training intent texts are the AGENS templates (csi.py, USER_NEED_TEMPLATES).
TRAIN_TEXTS = {
    0: ["I would like the network to offer as high a data rate as possible for HD video streaming and large file downloads.",
        "Please prioritize throughput. I need to transfer a large amount of data and require a high data rate.",
        "This session needs high bandwidth support. Please maximize the downlink data rate.",
        "Configure the link for a high-throughput scenario, such as video streaming or cloud gaming."],
    1: ["I care more about reliability and latency. The bit error rate should be extremely low with minimal delay.",
        "This is similar to an industrial control scenario and requires ultra-reliable, low-latency communication.",
        "Please prioritize link stability and delay, even at the cost of reduced data rate.",
        "This link must avoid packet loss and retransmissions as much as possible, with very strict latency requirements."],
    2: ["I want to minimize the transmit power and prioritize energy-efficient communication.",
        "The current service does not need a high data rate, so reducing power consumption and extending battery life is preferred.",
        "Please reduce power consumption as much as possible while maintaining basic connectivity.",
        "I prefer a low-power configuration, even if that means sacrificing some throughput."],
}
# Held-out paraphrases (never seen in training).
TEST_TEXTS = {
    0: ["We are uploading large sensor logs, so push the data rate as high as the channel allows.",
        "Maximize throughput for a cloud gaming session.",
        "Give me the fastest possible download speed."],
    1: ["Robot arm control traffic: errors are not acceptable and delay must stay very low.",
        "Keep the link extremely reliable; I can live with a lower data rate.",
        "Mission-critical telemetry, avoid any packet loss."],
    2: ["Battery is low, please save energy and keep transmit power minimal.",
        "Use the most power-efficient configuration that keeps the connection alive.",
        "Energy matters more than speed for this sensor."],
    4: ["The link must be very reliable but please also keep transmit power low to save battery.",
        "Reliable delivery with minimal energy consumption, data rate is not important."],
    3: ["Just make it work as well as possible.", "Do whatever is best.", "Configure something reasonable."],
}

EVENT_TYPES = ["regime", "blockage", "intent", "transient", "restate"]
POSITIVE = {"regime", "blockage", "intent"}
CAUSE_ID = {"none": 0, "regime": 1, "blockage": 2, "intent": 3, "transient": 4, "restate": 0}


@dataclass
class Event:
    t: int
    kind: str
    info: dict = field(default_factory=dict)


@dataclass
class EpisodeSpec:
    T: int
    regimes: List[tuple]          # (t_start, regime_name)
    intents: List[tuple]          # (t_start, intent_id, text)
    fades: List[tuple]            # (t, duration, depth_db)
    blockages: List[int]          # t of sustained blockage (lasts until next regime switch)
    caps: List[tuple]             # (t_start, t_end, cap_idx)
    snr_shift: float = 0.0
    events: List[Event] = field(default_factory=list)


def _texts(pool, intent, rng):
    return pool[intent][int(rng.integers(len(pool[intent])))]


def make_spec(kind: str, T: int, rng: np.random.Generator) -> EpisodeSpec:
    """kind in {'train', 'calib', 'A', 'B', 'C'}."""
    reg_pool = TRAIN_REGIMES if kind in ("train", "calib", "A") else (UNSEEN_REGIMES + TRAIN_REGIMES[:2] if kind == "B" else TRAIN_REGIMES + UNSEEN_REGIMES)
    text_pool = TRAIN_TEXTS if kind in ("train", "calib", "A") else TEST_TEXTS
    intent_pool = [0, 1, 2] if kind in ("train", "calib", "A") else ([0, 1, 2, 4] if kind == "B" else [0, 1, 2, 3, 4])
    n_reg = max(1, T // 75); n_int = max(1, T // 75); n_fade = max(1, T // 60)
    slots = np.arange(15, T - 10)
    pos = np.sort(rng.choice(slots, size=n_reg + n_int + n_fade + 1, replace=False))
    # enforce >= 8 cycles separation by resampling greedily
    chosen = []
    for p in rng.permutation(slots):
        if all(abs(p - c) >= 10 for c in chosen):
            chosen.append(int(p))
        if len(chosen) == n_reg + n_int + n_fade + 1:
            break
    chosen = list(rng.permutation(chosen))
    reg_t = sorted(chosen[:n_reg]); int_t = sorted(chosen[n_reg:n_reg + n_int])
    fade_t = sorted(chosen[n_reg + n_int:n_reg + n_int + n_fade]); extra = chosen[-1]
    r0 = reg_pool[int(rng.integers(len(reg_pool)))]
    regimes = [(0, r0)]; cur = r0
    for t in reg_t:
        nxt = [r for r in reg_pool if r != cur]
        cur = nxt[int(rng.integers(len(nxt)))]; regimes.append((t, cur))
    i0 = intent_pool[int(rng.integers(len(intent_pool)))]
    intents = [(0, i0, _texts(text_pool, i0, rng))]; ci = i0
    events = [Event(t, "regime", {"to": r}) for t, r in regimes[1:]]
    for t in int_t:
        nxt = [i for i in intent_pool if i != ci]
        ci = nxt[int(rng.integers(len(nxt)))]
        intents.append((t, ci, _texts(text_pool, ci, rng))); events.append(Event(t, "intent", {"to": ci}))
    fades = []
    for t in fade_t:
        d = int(rng.integers(1, 3)); depth = float(rng.uniform(10, 14)); fades.append((t, d, depth))
        events.append(Event(t, "transient", {"dur": d, "depth": depth}))
    blockages, caps = [], []
    if kind in ("calib", "train", "A", "B"):
        if rng.uniform() < 0.6:
            blockages.append(extra); events.append(Event(extra, "blockage", {}))
    if kind in ("calib", "A", "C", "B"):
        # paraphrased restatement of the current intent (semantic no-op, negative event)
        cand = [t for t in range(20, T - 10) if all(abs(t - e.t) >= 6 for e in events)]
        if cand:
            t = int(cand[int(rng.integers(len(cand)))])
            cur_i = [x for x in intents if x[0] <= t][-1][1]
            pool = text_pool if cur_i in text_pool else TEST_TEXTS
            alts = [s for s in pool[cur_i] if s != [x for x in intents if x[0] <= t][-1][2]] or pool[cur_i]
            intents.append((t, cur_i, alts[int(rng.integers(len(alts)))])); intents.sort(key=lambda x: x[0])
            events.append(Event(t, "restate", {}))
    if kind == "C":
        # intent reversal shortly after a drift and co-located channel + intent change
        t_rev = int_t[0] + 6 if int_t else 40
        prev = [x for x in intents if x[0] < (int_t[0] if int_t else 0)][-1][1] if int_t else i0
        intents.append((t_rev, prev, _texts(TEST_TEXTS, prev, rng))); events.append(Event(t_rev, "intent", {"to": prev, "reversal": True}))
        if reg_t:
            tc = reg_t[-1]
            nxt = [i for i in intent_pool if i != [x for x in intents if x[0] <= tc][-1][1]]
            ii = nxt[int(rng.integers(len(nxt)))]
            intents.append((tc, ii, _texts(TEST_TEXTS, ii, rng))); events.append(Event(tc, "intent", {"to": ii, "joint": True}))
        intents.sort(key=lambda x: x[0])
        for _ in range(2):
            a = int(rng.integers(10, T - 40)); caps.append((a, a + int(rng.integers(15, 35)), int(rng.integers(1, 4))))
    events.sort(key=lambda e: e.t)
    return EpisodeSpec(T, regimes, intents, fades, blockages, caps, -3.0 if kind == "B" else 0.0, events)


@dataclass
class Cycle:
    t: int
    regime: str
    intent: int
    text: str
    env: EnvelopeState
    snr_db: float
    feat: np.ndarray        # CSI report features of this cycle (visible from t+1 on)
    tables: dict
    blocked: bool
    fade_db: float
    cs: object = None


class Episode:
    """Pre-computes every cycle's KPI tables for all 7560 actions (common random numbers)."""

    COV_WARMUP = 5

    def __init__(self, spec: EpisodeSpec, seed: int, keep_tables=True, cov_invalid_from: int = 10**9):
        self.spec = spec
        rng = np.random.default_rng(seed)
        self.rng = rng
        reg_map = dict(spec.regimes)
        intent_ch = {t: (i, s) for t, i, s in spec.intents}
        fade = {}
        for t, d, depth in spec.fades:
            for k in range(d):
                fade[t + k] = depth
        ch = Channel(REGIMES[spec.regimes[0][1]], rng)
        shadow = 0.0; interf_ar = 0.0; blocked = False; last_switch = -100
        cur_reg = spec.regimes[0][1]; cur_int, cur_txt = intent_ch[0]
        self.cycles: List[Cycle] = []
        Hprev = None
        for t in range(spec.T):
            if t in reg_map and t > 0:
                cur_reg = reg_map[t]; ch.set_regime(REGIMES[cur_reg]); last_switch = t; blocked = False
            if t in spec.blockages:
                blocked = True; last_switch = t
                r = REGIMES[cur_reg]
                ch.set_regime(Regime(r.name + "+blocked", None, r.tau_ns * 1.5, r.speed_kmh, r.snr_db, r.interf_db, r.bs_corr))
            if t in intent_ch:
                cur_int, cur_txt = intent_ch[t]
            reg = ch.reg
            ch.step()
            H = ch.freq_response(); Htx = ch.tx_csi()
            shadow = 0.95 * shadow + np.sqrt(1 - 0.95 ** 2) * rng.normal(0, 2.0)
            interf_ar = 0.9 * interf_ar + np.sqrt(1 - 0.81) * rng.normal(0, 1.0)
            snr = REGIMES[cur_reg].snr_db + spec.snr_shift + shadow - (10.0 if blocked else 0.0) - fade.get(t, 0.0)
            cap = 6
            for a, b, c in spec.caps:
                if a <= t < b:
                    cap = c
            env = EnvelopeState(cap, (t - last_switch) >= self.COV_WARMUP and t < cov_invalid_from)
            cs = CycleState(H, Htx, snr, max(REGIMES[cur_reg].interf_db + interf_ar, -10), reg, env.cov_valid,
                            (rng.normal(size=(NSUB, NR, NS)) + 1j * rng.normal(size=(NSUB, NR, NS))) / np.sqrt(2),
                            rng.uniform(size=M_SLOTS), rng.normal(size=3))
            tables = kpi_tables(cs, cur_int)
            if not keep_tables:
                tables = {k: tables[k] for k in ("reward",)}
            feat = csi_features(H, Hprev, snr, rng)
            Hprev = H
            self.cycles.append(Cycle(t, cur_reg, cur_int, cur_txt, env, snr, feat, tables, blocked, fade.get(t, 0.0), cs))

    def __len__(self):
        return len(self.cycles)
