"""Re-run the calibration stage (CUSUM scan incl. adaptive reference tracking, BOCPD, fusion) with trained models."""
import json, os, pickle, sys, time
import numpy as np
from train import (OUT, collect_rollouts, offline_cusum, simulate_trigger, event_list, pick_tau, fit_lr)
from triggers import CUSUM, BOCPD, event_metrics
from run_experiments import load_models

def offline_cusum2(xk_seq, resets, k, h, sigma, track):
    c = CUSUM(k=k, h=h, sigma=np.asarray(sigma), track=track)
    lam = np.zeros(len(xk_seq))
    for t, x in enumerate(xk_seq):
        if np.all(np.isfinite(x)):
            lam[t] = c.update(x) / h      # statistic uses KPI_{t-1}, computed before the decision at t
        if resets[t]:
            c.reset()                     # a re-plan at t resets the detector afterwards (as online)
    return lam

def main():
    t0 = time.time()
    models = load_models()
    # behaviour policy for calibration: memory generator re-planned on a fixed 20-cycle schedule, so that
    # detector statistics evolve through events as they would before a trigger fires online
    import train as TR
    from agent import Method, run_episode, cycle_reference
    from scenarios import make_spec, Episode
    cal_ro = []
    for k in range(60):
        sd = 300000 + k
        spec = make_spec("calib", 100, np.random.default_rng(sd)); ep = Episode(spec, sd)
        refs = [cycle_reference(c) for c in ep.cycles]
        log = run_episode(ep, Method("collect", generator="mem", trigger="fixed", period=20), models, refs)
        y, cause = TR.cycle_labels(spec, 100)
        cal_ro.append({"spec": spec, "log": log, "y": y, "cause": cause, "replan": log["replan"]})
    pickle.dump(cal_ro, open(os.path.join(OUT, "calib_rollouts.pkl"), "wb"))
    T = 100
    diffs = []
    for r in cal_ro:
        xk = r["log"]["x_kpi"]; quiet = (r["y"] == 0)
        d = np.diff(xk, axis=0)[quiet[1:] & quiet[:-1] & ~r["replan"][1:].astype(bool)]
        diffs.append(d[np.all(np.isfinite(d), axis=1)])
    diffs = np.concatenate(diffs)
    sigma = (np.std(diffs, 0) / np.sqrt(2)).clip(0.05, None)
    specs = [r["spec"] for r in cal_ro]; resets = [r["replan"].astype(bool) for r in cal_ro]
    bvar = float(np.var(diffs[:, 2]) / 2)
    cps = []
    for r in cal_ro:
        b = BOCPD(hazard=0.01, var=bvar); cp = np.zeros(T)
        for t in range(1, T):
            x = r["log"]["x_kpi"][t]
            cp[t] = b.update(x[2]) if np.isfinite(x[2]) else 0.0
            if r["replan"][t]:
                b.reset()
        cps.append(cp)
    scan = []
    for track in (0.02, 0.1, 0.3):
        for k in (0.25, 0.5, 1.0, 1.5, 2.0, 3.0):
            for h in (2, 3, 4, 5, 6, 8, 10, 15, 20):
                lams = [offline_cusum2(r["log"]["x_kpi"], rs, k, h, sigma, track) for r, rs in zip(cal_ro, resets)]
                ms = [event_metrics(simulate_trigger(l, 0.999), event_list(sp), T) for l, sp in zip(lams, specs)]
                scan.append({"track": track, "k": k, "h": h, "f1": float(np.mean([m["f1"] for m in ms])),
                             "fpr": float(np.mean([m["fpr"] for m in ms])), "recall": float(np.mean([m["recall"] for m in ms])),
                             "precision": float(np.mean([m["precision"] for m in ms]))})
    ok = [s for s in scan if s["fpr"] <= 0.05] or scan
    best = max(ok, key=lambda s: s["f1"])
    print("CUSUM best", best)
    json.dump(scan, open(os.path.join(OUT, "cusum_scan.json"), "w"))
    lams = [offline_cusum2(r["log"]["x_kpi"], rs, best["k"], best["h"], sigma, best["track"]) for r, rs in zip(cal_ro, resets)]
    S = [np.clip(r["log"]["s"], 1e-4, 1 - 1e-4) for r in cal_ro]
    Phi = [np.stack([np.log(s / (1 - s)), l, c, s * l], 1) for s, l, c in zip(S, lams, cps)]
    Yc = np.concatenate([r["y"] for r in cal_ro]); Pc = np.concatenate(Phi)
    calib = {"cusum_k": best["k"], "cusum_h": best["h"], "cusum_track": best["track"], "cusum_cal": best,
             "kpi_sigma": sigma.tolist(), "bocpd_hazard": 0.01, "bocpd_var": bvar}
    # BOCPD alone for reference
    ms = [event_metrics(simulate_trigger(c, 0.5), event_list(sp), T) for c, sp in zip(cps, specs)]
    calib["bocpd_alone_tau05"] = {"f1": float(np.mean([m["f1"] for m in ms])), "fpr": float(np.mean([m["fpr"] for m in ms]))}
    # ---- stage A: LR fit on fixed-schedule logs (initialisation)
    import copy
    eps = []
    for k in range(60):
        sd = 300000 + k
        spec = make_spec("calib", 100, np.random.default_rng(sd)); ep = Episode(spec, sd)
        eps.append((spec, ep, [cycle_reference(c) for c in ep.cycles], TR.cycle_labels(spec, 100)[0]))
    trig_name = {"sem": "sem", "stat": "stat", "fusion": "fusion"}
    for fam, cols in (("sem", [0]), ("stat", [1, 2]), ("fusion", [0, 1, 2, 3])):
        w, b = fit_lr(Pc[:, cols], Yc)
        wf = np.zeros(4); wf[cols] = w
        calib[fam] = {"w": wf.tolist(), "b": b, "tau": 0.5}
    models.calib = calib
    # ---- stage B: on-policy refit (one iteration) and online threshold sweep (closed loop, cooldown active)
    def online_eval(fam, tau):
        cal = copy.deepcopy(models.calib); cal[fam]["tau"] = tau; models.calib = cal
        tp = nt = det = ne = 0; fprs = []; PH = []; YY = []
        for spec, ep, refs, y in eps:
            log = run_episode(ep, Method("cal", generator="mem", trigger=fam), models, refs)
            trig = [t for t in np.flatnonzero(log["trigger"]) if t > 0]
            m = event_metrics(trig, event_list(spec), 100)
            tp += m["tp"]; nt += m["n_trig"]; det += m["detected"]; ne += m["n_events"]; fprs.append(m["fpr"])
            s = np.clip(log["s"], 1e-4, 1 - 1e-4)
            PH.append(np.stack([np.log(s / (1 - s)), log["lam"], log["cp"], s * log["lam"]], 1)); YY.append(y)
        p = tp / nt if nt else 0; r = det / ne if ne else 0
        return {"tau": float(tau), "f1": 2 * p * r / (p + r) if p + r else 0.0, "precision": p, "recall": r, "fpr": float(np.mean(fprs))}, PH, YY
    sweep_log = {}
    for fam, cols in (("sem", [0]), ("stat", [1, 2]), ("fusion", [0, 1, 2, 3])):
        _, PH, YY = online_eval(fam, 0.5)
        P2 = np.concatenate([Pc] + PH); Y2 = np.concatenate([Yc] + YY)
        w, b = fit_lr(P2[:, cols], Y2)
        wf = np.zeros(4); wf[cols] = w
        models.calib[fam]["w"] = wf.tolist(); models.calib[fam]["b"] = b
        res = [online_eval(fam, tau)[0] for tau in np.linspace(0.30, 0.98, 18)]
        sweep_log[fam] = res
        ok = [r for r in res if r["fpr"] <= 0.05] or res
        best = max(ok, key=lambda r: r["f1"])
        models.calib[fam].update({"tau": best["tau"], "cal_f1": best["f1"], "cal_prec": best["precision"], "cal_rec": best["recall"], "cal_fpr": best["fpr"]})
        print(fam, {k: (round(v, 3) if isinstance(v, float) else v) for k, v in models.calib[fam].items() if k != "w"}, np.round(wf, 3))
    calib = models.calib
    json.dump(sweep_log, open(os.path.join(OUT, "tau_sweep.json"), "w"), indent=1)
    json.dump(calib, open(os.path.join(OUT, "calib.json"), "w"), indent=1)
    print("done", time.time() - t0)

if __name__ == "__main__":
    main()
