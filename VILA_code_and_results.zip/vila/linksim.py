"""Time-varying closed-loop link-abstraction simulator.

A vectorised surrogate of the AGENS Sionna link (4x2 MIMO-OFDM, 2 streams, 30 kHz SCS, 128-point
FFT, 108 used sub-carriers, 12 data OFDM symbols per slot). For every cycle it returns the
KPI-mean reward of *all* 7560 raw actions, which allows exact oracles, exact policy gradients and
common-random-number comparisons across methods.

Physical abstraction per cycle:
  tapped-delay-line MIMO channel (Rician/Rayleigh, exponential PDP, Kronecker correlation),
  AR(1) temporal evolution with rho = J0(2 pi f_D T_c), delayed Tx CSI for precoding (ZF / RZF),
  pilot-based estimation error per estimator (LS-NN / LS-Lin / LMMSE), linear equaliser SINR
  (LMMSE / MF / ZF) with estimation error and hidden interference, hardware EVM floor,
  EESM effective SINR, code-specific logistic BLER curves, M=10 slots per cycle.
The reward follows AGENS `rl_reward` (communication.py) with an intent-conditioned BER reference.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional

import numpy as np
from scipy.special import j0

from actions import DIMS, MOD_BITS, POWER_DB, RATES

NT, NR, NS = 4, 2, 2
NSUB = 12                 # sub-band samples covering 108 sub-carriers
DF_SUB = 9 * 30e3         # sub-band spacing [Hz]
FC = 3.5e9
T_CYCLE = 5e-3            # decision cycle [s] (10 slots of 0.5 ms)
T_FB = 2e-3               # Tx CSI (SRS) delay for precoding [s]
M_SLOTS = 10
N_DATA_RE = 1296          # data REs per stream per slot (108 x 12)
N_TOTAL_RE = 128 * 14     # AGENS rate normalisation (fft_size x OFDM symbols)
EVM_FLOOR = 10 ** (-28 / 10)

# code-specific BLER model: SNR gap to Shannon [dB], logistic scale [dB], residual BER of failed block
CODE_GAP = np.array([1.2, 2.2, 2.8])
CODE_SLOPE = np.array([0.25, 0.40, 0.50])
CODE_EFAIL = np.array([0.10, 0.12, 0.06])
BICM_LOSS = 0.15          # dB per bit/symbol
HIGH_RATE_PENALTY = 0.4   # dB extra for R=0.8 (puncturing)
EESM_BETA = np.array([1.5, 5.5, 18.0, 55.0])
# execution-time proxy [s] (mirrors relative cost of Sionna decoders/estimators)
T_CODE = np.array([0.20, 0.50, 0.30])
T_CE = np.array([0.02, 0.03, 0.12])
T_EQ = np.array([0.03, 0.02, 0.03])

# intent -> AGENS reward weights (w_ber, w_rate, w_time, w_power) and BER reference
INTENT_WEIGHTS = {
    0: (0.05, 0.80, 0.10, 0.05),  # high data rate
    1: (0.80, 0.05, 0.10, 0.05),  # URLLC
    2: (0.10, 0.05, 0.05, 0.80),  # energy saving
    3: (0.40, 0.30, 0.15, 0.15),  # balanced / ambiguous fallback
    4: (0.45, 0.05, 0.05, 0.45),  # dual: reliability + low power (unseen in training)
}
INTENT_BER_REF = {0: 1e-2, 1: 1e-5, 2: 1e-2, 3: 1e-2, 4: 1e-4}
INTENT_NAMES = {0: "high-throughput", 1: "high-reliability", 2: "energy-saving", 3: "balanced", 4: "reliable+low-power"}


# ----------------------------------------------------------------------------- AGENS reward (vectorised port)

def norm_ber(ber, ber_ref):
    ber = np.asarray(ber, dtype=float)
    lr = -np.log10(ber_ref)
    t = ber_ref / 5
    out = np.where(ber < 0.1 + t, -np.log10(ber + 1e-12) / lr,
          np.where(ber < 0.25 + t, 0.5 * (0.25 - ber) / 0.25,
          np.where(ber < 0.3 + t, -15.0 * (ber - 0.25), -200.0 * (ber - 0.25))))
    return np.clip(out, -8.0, 1.0)


def norm_rate(r, rate_ref=3.0):
    r = np.asarray(r, dtype=float)
    out = np.where(r <= 0, -2.0, np.where(r < rate_ref, r / rate_ref, 1.0 + 0.2 * (r - rate_ref) / max(1e-6, 4.0 - rate_ref)))
    return np.clip(out, -2.0, 1.2)


def norm_time(t, time_ref=0.6):
    t = np.asarray(t, dtype=float)
    out = np.where(t <= 0, 1.0, np.where(t <= time_ref, 1 - t / time_ref,
          np.where(t <= 3 * time_ref, -(t - time_ref) / (2 * time_ref), -1.0 - (t - 3 * time_ref) / time_ref)))
    return np.clip(out, -5.0, 1.0)


def norm_power(p, pref=0.921):
    p = np.asarray(p, dtype=float)
    out = np.where(p <= 0, 1.0, np.where(p <= pref, 1 - p / pref, np.where(p <= 2 * pref, -(p - pref) / pref, -1.0 - (p - 2 * pref) / pref)))
    return np.clip(out, -5.0, 1.0)


def reward_from_kpi(ber, rate, time_s, p_extra, intent: int):
    wb, wr, wt, wp = INTENT_WEIGHTS[intent]
    s = wb + wr + wt + wp
    return (wb * norm_ber(ber, INTENT_BER_REF[intent]) + wr * norm_rate(rate) + wt * norm_time(time_s)
            + wp * norm_power(p_extra)) / s


# ----------------------------------------------------------------------------- channel

@dataclass
class Regime:
    name: str
    k_db: Optional[float]   # Rician K factor (None = Rayleigh)
    tau_ns: float           # RMS delay spread
    speed_kmh: float
    snr_db: float           # mean SNR
    interf_db: float        # hidden interference-over-noise (not visible in CSI report)
    bs_corr: float = 0.5


REGIMES: Dict[str, Regime] = {
    # training / in-distribution
    "UMi-LOS-ped": Regime("UMi-LOS-ped", 6.0, 40, 3, 22, 0.0),
    "UMi-NLOS-ped": Regime("UMi-NLOS-ped", None, 120, 3, 16, 2.0),
    "UMa-NLOS-veh": Regime("UMa-NLOS-veh", None, 300, 60, 14, 1.0),
    "InH-LOS": Regime("InH-LOS", 3.0, 30, 1, 26, 0.0),
    "Edge-Interf": Regime("Edge-Interf", None, 150, 3, 12, 6.0),
    # unseen (test set B)
    "HST-LOS": Regime("HST-LOS", 9.0, 50, 120, 18, 0.0, 0.8),
    "Dense-Rich": Regime("Dense-Rich", None, 500, 30, 8, 4.0, 0.3),
    "Rank1-LOS": Regime("Rank1-LOS", 12.0, 20, 3, 24, 1.0, 0.9),
}
TRAIN_REGIMES = ["UMi-LOS-ped", "UMi-NLOS-ped", "UMa-NLOS-veh", "InH-LOS", "Edge-Interf"]
UNSEEN_REGIMES = ["HST-LOS", "Dense-Rich", "Rank1-LOS"]


def _expcorr(n, rho):
    i = np.arange(n)
    return rho ** np.abs(i[:, None] - i[None, :])


def _sqrtm_psd(R):
    w, V = np.linalg.eigh(R)
    return (V * np.sqrt(np.maximum(w, 0))) @ V.conj().T


class Channel:
    """Per-episode channel state with regime switching and AR(1) evolution."""

    L = 6

    def __init__(self, regime: Regime, rng: np.random.Generator):
        self.rng = rng
        self.set_regime(regime, keep_fading=False)

    def set_regime(self, regime: Regime, keep_fading=True):
        rng = self.rng
        self.reg = regime
        self.delays = np.sort(rng.uniform(0, 3 * regime.tau_ns * 1e-9, self.L)); self.delays[0] = 0
        p = np.exp(-self.delays / max(regime.tau_ns * 1e-9, 1e-12)); self.pdp = p / p.sum()
        self.Rt = _sqrtm_psd(_expcorr(NT, regime.bs_corr)); self.Rr = _sqrtm_psd(_expcorr(NR, 0.3))
        if not keep_fading or not hasattr(self, "W"):
            self.W = (rng.normal(size=(self.L, NR, NT)) + 1j * rng.normal(size=(self.L, NR, NT))) / np.sqrt(2)
        th_t, th_r = rng.uniform(-np.pi / 3, np.pi / 3, 2)
        self.at = np.exp(1j * np.pi * np.arange(NT) * np.sin(th_t)) ; self.ar = np.exp(1j * np.pi * np.arange(NR) * np.sin(th_r))
        self.los_phase = rng.uniform(0, 2 * np.pi); self.los_cos = np.cos(rng.uniform(0, np.pi))
        fd = regime.speed_kmh / 3.6 * FC / 3e8
        self.fd = fd
        self.rho = float(j0(2 * np.pi * fd * T_CYCLE)); self.rho_fb = float(j0(2 * np.pi * fd * T_FB))

    def step(self):
        rng = self.rng
        N = (rng.normal(size=self.W.shape) + 1j * rng.normal(size=self.W.shape)) / np.sqrt(2)
        self.W = self.rho * self.W + np.sqrt(max(1 - self.rho ** 2, 0)) * N
        self.los_phase += 2 * np.pi * self.fd * T_CYCLE * self.los_cos

    def freq_response(self, W=None) -> np.ndarray:
        W = self.W if W is None else W
        k = self.reg.k_db
        Kl = 0.0 if k is None else 10 ** (k / 10)
        taps = np.sqrt(self.pdp)[:, None, None] * (self.Rr @ W @ self.Rt.T) * np.sqrt(1 / (1 + Kl))
        f = np.arange(NSUB) * DF_SUB
        ph = np.exp(-2j * np.pi * f[:, None] * self.delays[None, :])  # (K, L)
        H = np.einsum("kl,lrt->krt", ph, taps)
        if Kl > 0:
            H = H + np.sqrt(Kl / (1 + Kl)) * np.exp(1j * self.los_phase) * np.outer(self.ar, self.at.conj())[None]
        return H  # (K, NR, NT), E|h|^2 ~ 1

    def tx_csi(self) -> np.ndarray:
        rng = self.rng
        N = (rng.normal(size=self.W.shape) + 1j * rng.normal(size=self.W.shape)) / np.sqrt(2)
        Wd = self.rho_fb * self.W + np.sqrt(max(1 - self.rho_fb ** 2, 0)) * N
        return self.freq_response(Wd)


# ----------------------------------------------------------------------------- link abstraction

def _inv2(A):
    a, b, c, d = A[..., 0, 0], A[..., 0, 1], A[..., 1, 0], A[..., 1, 1]
    det = a * d - b * c
    out = np.empty_like(A)
    out[..., 0, 0] = d; out[..., 0, 1] = -b; out[..., 1, 0] = -c; out[..., 1, 1] = a
    return out / det[..., None, None]


def precoders(Htx: np.ndarray) -> np.ndarray:
    """ZF (alpha=0) and RZF (alpha=2) precoders as in the AGENS RZFPrecoder calls. -> (2, K, NT, NS)"""
    Hh = np.conj(np.transpose(Htx, (0, 2, 1)))
    G = Htx @ Hh
    out = []
    for alpha in (1e-6, 2.0):
        Wp = Hh @ np.linalg.inv(G + alpha * np.eye(NR)[None])
        Wp = Wp / np.linalg.norm(Wp, axis=1, keepdims=True)
        out.append(Wp)
    return np.stack(out)


def ce_error_var(sigma_n2: np.ndarray, reg: Regime, cov_valid: bool) -> np.ndarray:
    """Normalised estimation-error variance per estimator. sigma_n2 shape (P,) -> (P, 3)."""
    fd = reg.speed_kmh / 3.6 * FC / 3e8
    e_t = (2 * np.pi * fd * 125e-6) ** 2              # pilot-gap time interpolation error
    e_f = (2 * np.pi * reg.tau_ns * 1e-9 * 60e3) ** 2  # pilot-spacing frequency interpolation error
    e_nn = e_t + e_f
    g_lmmse = 1 + 6 * np.exp(-reg.tau_ns / 300.0)
    nn = sigma_n2 + e_nn
    lin = 0.75 * sigma_n2 + 0.25 * e_nn
    if cov_valid:
        lm = sigma_n2 / g_lmmse + 0.1 * e_nn
    else:
        lm = 1.2 * sigma_n2 + 1.5 * e_nn + 0.02    # mismatched covariance
    return np.stack([nn, lin, lm], axis=-1)


@dataclass
class CycleState:
    H: np.ndarray
    Htx: np.ndarray
    snr_db: float
    interf_db: float
    reg: Regime
    cov_valid: bool
    Z: np.ndarray            # (K, NR, NS) standard complex normal for estimation error (CRN)
    U: np.ndarray            # (M,) uniforms for slot errors (CRN)
    meas_noise: np.ndarray   # (3,) KPI measurement noise


def sinr_table(cs: CycleState) -> np.ndarray:
    """Post-equaliser SINR [linear] -> shape (P=7, CE=3, PREC=2, EQ=3, K*NS)."""
    snr = 10 ** (cs.snr_db / 10)
    I = 10 ** (cs.interf_db / 10)
    Wp = precoders(cs.Htx)                                   # (2, K, NT, NS)
    G = np.einsum("krt,pkts->pkrs", cs.H, Wp)                # (2, K, NR, NS)
    rho = snr * 10 ** (POWER_DB / 10) / NS                   # (P,)
    sigma_n2 = (1 + I) / rho                                 # (P,)
    sig_e2 = ce_error_var(sigma_n2, cs.reg, cs.cov_valid)    # (P, 3)
    E = np.sqrt(sig_e2)[:, :, None, None, None, None] * cs.Z[None, None, None]  # (P,3,1,K,NR,NS)
    Gt = G[None, None]                                       # (1,1,2,K,NR,NS)
    Gh = Gt + E                                              # (P,3,2,K,NR,NS)
    GhH = np.conj(np.swapaxes(Gh, -1, -2))
    s2 = sigma_n2[:, None, None, None]
    out = np.empty((7, 3, 2, 3, NSUB, NS))
    # LMMSE
    A = Gh @ GhH + (s2 + NS * sig_e2[:, :, None, None])[..., None, None] * np.eye(NR)
    F_l = GhH @ _inv2(A)
    # ZF
    F_z = _inv2(Gh)
    # MF
    F_m = GhH
    for qi, F in enumerate((F_l, F_m, F_z)):
        FG = F @ Gt                                           # (P,3,2,K,NS,NS)
        sig = np.abs(np.diagonal(FG, axis1=-2, axis2=-1)) ** 2
        tot = np.sum(np.abs(FG) ** 2, axis=-1)
        fn = np.sum(np.abs(F) ** 2, axis=-1)
        sinr = sig / (tot - sig + fn * s2[..., None] + 1e-15)
        out[:, :, :, qi] = 1 / (1 / sinr + EVM_FLOOR)
    return out.reshape(7, 3, 2, 3, NSUB * NS)


def kpi_tables(cs: CycleState, intent: int):
    """Return dict with arrays over DIMS: bler, ber, rate, time, p_extra, reward (KPI-mean),
    and realised (CRN) ber_obs, rate_obs, reward_obs."""
    S = sinr_table(cs)                                        # (P,CE,PR,EQ,24)
    # EESM per modulation -> (4, P, CE, PR, EQ)
    eff = np.stack([-b * np.log(np.mean(np.exp(-S / b), axis=-1) + 1e-300) for b in EESM_BETA])
    eff_db = 10 * np.log10(np.maximum(eff, 1e-12))
    m = MOD_BITS[:, None, None]                               # (4,1,1)
    se = m * RATES[None, :, None]                             # (4,5,1)
    thr = 10 * np.log10(2 ** se - 1) + CODE_GAP[None, None, :] + BICM_LOSS * m
    thr = thr + HIGH_RATE_PENALTY * (RATES[None, :, None] > 0.79) * (np.arange(3)[None, None, :] < 2)
    # bler over (mod, rate, P, code, CE, EQ, PREC)
    x = eff_db[:, None]                                       # (4,1,P,CE,PR,EQ)
    x = np.transpose(x, (0, 1, 2, 3, 5, 4))                   # (4,1,P,CE,EQ,PR)
    z = (x[:, :, :, None] - thr[:, :, None, :, None, None, None]) / CODE_SLOPE[None, None, None, :, None, None, None]
    bler = 1 / (1 + np.exp(np.clip(z, -60, 60)))              # (4,5,P,3,CE,EQ,PR)
    efail = CODE_EFAIL[None, None, None, :, None, None, None]
    ber = np.maximum(bler * efail, 1e-9)
    k_bits = N_DATA_RE * MOD_BITS[:, None] * RATES[None, :]    # (4,5)
    rate_nom = (N_DATA_RE * MOD_BITS[:, None] * RATES[None, :] / N_TOTAL_RE)[:, :, None, None, None, None, None]
    rate = rate_nom * (1 - bler)
    tsec = (T_CODE[None, None, None, :, None, None, None] * (NS * k_bits / 4000)[:, :, None, None, None, None, None]
            + T_CE[None, None, None, None, :, None, None] + T_EQ[None, None, None, None, None, :, None])
    p_extra = np.log(10 ** (POWER_DB / 10))[None, None, :, None, None, None, None]
    shape = DIMS
    tsec = np.broadcast_to(tsec, shape); p_extra = np.broadcast_to(p_extra, shape)
    reward = reward_from_kpi(ber, rate, tsec, p_extra, intent)
    # realised KPIs via common random numbers
    nfail = np.sum(cs.U[:, None, None, None, None, None, None, None] < bler[None], axis=0)
    frac = nfail / M_SLOTS
    ber_obs = frac * efail * (1 + 0.1 * cs.meas_noise[0])
    rate_obs = rate_nom * (1 - frac)
    return {"bler": bler, "ber": ber, "rate": rate, "time": tsec, "p_extra": p_extra, "reward": reward,
            "frac": frac, "ber_obs": ber_obs, "rate_obs": rate_obs, "eff_db": eff_db}


def reward_for_intent(tables, intent: int) -> np.ndarray:
    return reward_from_kpi(tables["ber"], tables["rate"], tables["time"], tables["p_extra"], intent)


def csi_features(H: np.ndarray, Hprev: Optional[np.ndarray], snr_db: float, rng) -> np.ndarray:
    """Compact CSI-report features (what the policy observes): 24 per-subband singular values [dB],
    wideband SNR estimate, delay-spread proxy, Doppler proxy, K-factor proxy, condition number."""
    s = np.linalg.svd(H, compute_uv=False)                    # (K, 2)
    sv_db = 20 * np.log10(s + 1e-9) + rng.normal(0, 0.5, s.shape)
    gain = np.mean(np.abs(H) ** 2)
    snr_est = snr_db + 10 * np.log10(gain + 1e-12) + rng.normal(0, 0.5)
    h = H.reshape(NSUB, -1)
    c1 = np.abs(np.mean(np.sum(h[1:] * np.conj(h[:-1]), axis=1)) / (np.mean(np.sum(np.abs(h) ** 2, axis=1)) + 1e-12))
    ds = 1 - c1                                               # frequency decorrelation (delay spread proxy)
    if Hprev is None:
        dop = 0.0
    else:
        hp = Hprev.reshape(NSUB, -1)
        dop = 1 - np.abs(np.sum(h * np.conj(hp))) / (np.linalg.norm(h) * np.linalg.norm(hp) + 1e-12)
    mean_h = np.mean(H, axis=0)
    kf = 10 * np.log10(np.sum(np.abs(mean_h) ** 2) / (np.sum(np.abs(H - mean_h) ** 2) / NSUB + 1e-9) + 1e-6)
    cond = float(np.mean(sv_db[:, 0] - sv_db[:, 1]))
    return np.concatenate([sv_db.reshape(-1) / 10, [snr_est / 10, ds * 10, dop * 10, kf / 10, cond / 10]]).astype(np.float32)


N_CSI_FEAT = 2 * NSUB + 5
