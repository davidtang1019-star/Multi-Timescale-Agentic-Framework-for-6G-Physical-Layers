# VILA — Verifiable Intent-driven Link Adaptation (reproducibility package)

Closed-loop simulator, models, triggers, safety envelope and experiment scripts for the IEEE TMC manuscript.

## Requirements
Python 3.10+, numpy, scipy, torch (CPU is enough), scikit-learn, matplotlib, tokenizers.
GPT-2 BPE files (encoder.json, vocab.bpe) are needed only for token counting; set `GPT2_BPE_DIR`.

## Pipeline
```
python actions.py                 # exhaustive envelope verification (unit test, ~2 min)
python train.py                   # policy data (24k), generators (SFT+RL), reflection, initial calibration
python retrain_reflection.py      # reflection without leaky timing inputs (events_noisy behaviour policy)
python calibrate.py               # CUSUM scan, LR fusion, closed-loop tau sweep -> calib.json
python run_experiments.py A,B,C   # E1-E4, 19 methods x 20 seeds x 3 test sets
python run_latency.py             # E5 latency (exploratory)
python run_e2_e5.py               # E2 sensitivity, E5 probes, timing
python analyze.py                 # statistics -> summary.json
python figures.py main e25 lat    # figures and LaTeX table rows
```
Results are written to `$VILA_OUT` (default `../results`).

## Files
- `actions.py`  action space (AGENS layout), constraints C1-C4, prefix-completable decoding, projection, audit log, verification
- `linksim.py`  link-abstraction simulator, AGENS reward port
- `scenarios.py` regimes, intents (AGENS templates + held-out paraphrases), event injection, test sets A/B/C
- `memory.py`   semantic memory (buffer + recursive summary, GPT-2 BPE token budget, probes)
- `triggers.py` CUSUM, BOCPD, fusion trigger, event metrics
- `models.py`   compact generator / reflection networks (stand-ins for GPT-2 Medium + LoRA)
- `agent.py`    closed-loop runner for VILA and all baselines/ablations
