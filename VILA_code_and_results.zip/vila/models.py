"""Compact learned components used in the experiments.

These stand in for the GPT-2 Medium backbone of AGENS (no GPU / model download is available in the
experimental environment). Interfaces mirror the LLM version: an intent encoder (text -> preference
posterior), a multi-head actor (CSI features + intent + envelope + memory -> 7 head logits) trained
by SFT then expected-reward policy gradient, and a reflection scorer (serialised reflection inputs ->
deviation score s_t and cause attribution).
"""
from __future__ import annotations

import re
import zlib
from typing import List

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as Fnn

from actions import DIMS
from linksim import N_CSI_FEAT
from scenarios import TRAIN_TEXTS

torch.set_num_threads(2)


# ----------------------------------------------------------------------------- intent encoder
class IntentEncoder:
    D = 512

    def __init__(self, seed=0):
        self.rng = np.random.default_rng(seed)
        self.W = None

    @classmethod
    def bow(cls, text: str) -> np.ndarray:
        w = re.findall(r"[a-z]+", text.lower())
        toks = w + [a + "_" + b for a, b in zip(w, w[1:])]
        v = np.zeros(cls.D, dtype=np.float32)
        for t in toks:
            v[zlib.crc32(t.encode()) % cls.D] += 1.0
        n = np.linalg.norm(v)
        return v / n if n > 0 else v

    def fit(self):
        X, y = [], []
        for c, texts in TRAIN_TEXTS.items():
            for s in texts:
                words = s.split()
                for _ in range(150):
                    keep = [x for x in words if self.rng.uniform() > 0.25] or words
                    X.append(self.bow(" ".join(keep))); y.append(c)
        X = torch.tensor(np.array(X)); y = torch.tensor(y)
        lin = nn.Linear(self.D, 3)
        opt = torch.optim.Adam(lin.parameters(), lr=0.05, weight_decay=1e-4)
        for _ in range(300):
            opt.zero_grad(); loss = Fnn.cross_entropy(lin(X), y); loss.backward(); opt.step()
        self.lin = lin
        return self

    def probs(self, text: str) -> np.ndarray:
        with torch.no_grad():
            z = self.lin(torch.tensor(self.bow(text))[None])
            return torch.softmax(z / 1.0, -1).numpy()[0]


def js_div(p, q):
    p = np.asarray(p) + 1e-9; q = np.asarray(q) + 1e-9
    m = 0.5 * (p + q)
    return float(0.5 * np.sum(p * np.log(p / m)) + 0.5 * np.sum(q * np.log(q / m)))


# ----------------------------------------------------------------------------- policy generator
def policy_input_dim(mem_dim: int) -> int:
    return N_CSI_FEAT + 3 + 2 + mem_dim


class PolicyNet(nn.Module):
    def __init__(self, in_dim: int, hidden=256):
        super().__init__()
        self.body = nn.Sequential(nn.Linear(in_dim, hidden), nn.GELU(), nn.LayerNorm(hidden),
                                  nn.Linear(hidden, hidden), nn.GELU(), nn.LayerNorm(hidden),
                                  nn.Linear(hidden, hidden), nn.GELU())
        self.heads = nn.ModuleList([nn.Linear(hidden, d) for d in DIMS])

    def forward(self, x):
        h = self.body(x)
        return [hd(h) for hd in self.heads]

    @torch.no_grad()
    def logits_np(self, x: np.ndarray) -> List[np.ndarray]:
        out = self.forward(torch.tensor(x, dtype=torch.float32)[None])
        return [o[0].numpy() for o in out]


def expected_reward(logits, R, Fmask, penalty=-1.0, temp=1.0):
    """Exact expected reward of the factorised policy over the joint 7560-action table."""
    ps = [torch.softmax(l / temp, -1) for l in logits]
    Rt = torch.where(Fmask, R, torch.full_like(R, penalty))
    P = ps[0]
    for q in ps[1:]:
        P = (P[:, :, None] * q[:, None, :]).reshape(P.shape[0], -1)
    return (P * Rt).sum(-1)


def train_policy(X, Y, R, Fm, Xv, Yv, Rv, Fv, epochs_sft=30, epochs_rl=15, seed=0, log=print):
    torch.manual_seed(seed)
    net = PolicyNet(X.shape[1])
    X = torch.tensor(X); Y = torch.tensor(Y, dtype=torch.long)
    R = torch.tensor(R.astype(np.float32)); Fm = torch.tensor(Fm)
    Xv = torch.tensor(Xv); Yv = torch.tensor(Yv, dtype=torch.long)
    Rv = torch.tensor(Rv.astype(np.float32)); Fv = torch.tensor(Fv)
    opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=1e-4)
    n = len(X); bs = 256
    hist = []
    for ep in range(epochs_sft):
        net.train(); perm = torch.randperm(n)
        for i in range(0, n, bs):
            idx = perm[i:i + bs]
            out = net(X[idx])
            loss = sum(Fnn.cross_entropy(o, Y[idx, k]) for k, o in enumerate(out))
            opt.zero_grad(); loss.backward(); opt.step()
        net.eval()
        with torch.no_grad():
            Jv = expected_reward(net(Xv), Rv, Fv, temp=0.3).mean().item()
            acc = np.mean([(o.argmax(-1) == Yv[:, k]).float().mean().item() for k, o in enumerate(net(Xv))])
        hist.append(("sft", ep, Jv, acc)); log(f"SFT ep{ep} val J={Jv:.4f} head-acc={acc:.3f}")
    opt = torch.optim.AdamW(net.parameters(), lr=3e-4, weight_decay=1e-4)
    for ep in range(epochs_rl):
        net.train(); perm = torch.randperm(n)
        for i in range(0, n, bs):
            idx = perm[i:i + bs]
            out = net(X[idx])
            J = expected_reward(out, R[idx], Fm[idx], temp=0.5).mean()
            ent = sum(-(torch.softmax(o, -1) * torch.log_softmax(o, -1)).sum(-1).mean() for o in out)
            loss = -J - 1e-3 * ent
            opt.zero_grad(); loss.backward(); opt.step()
        net.eval()
        with torch.no_grad():
            Jv = expected_reward(net(Xv), Rv, Fv, temp=0.3).mean().item()
        hist.append(("rl", ep, Jv, np.nan)); log(f"RL ep{ep} val J={Jv:.4f}")
    return net, hist


# ----------------------------------------------------------------------------- reflection scorer
N_REFL_FEAT = 16
CAUSES = ["none", "regime", "blockage", "intent", "transient"]


class ReflectionNet(nn.Module):
    def __init__(self, in_dim=N_REFL_FEAT, hidden=64):
        super().__init__()
        self.body = nn.Sequential(nn.Linear(in_dim, hidden), nn.GELU(), nn.Linear(hidden, hidden), nn.GELU())
        self.score = nn.Linear(hidden, 1)
        self.cause = nn.Linear(hidden, len(CAUSES))

    def forward(self, x):
        h = self.body(x)
        return self.score(h).squeeze(-1), self.cause(h)

    @torch.no_grad()
    def predict(self, x: np.ndarray):
        s, c = self.forward(torch.tensor(x, dtype=torch.float32)[None])
        return float(torch.sigmoid(s)[0]), torch.softmax(c, -1)[0].numpy()


def train_reflection(X, y, c, Xv, yv, cv, epochs=60, seed=0, log=print):
    torch.manual_seed(seed)
    net = ReflectionNet(X.shape[1])
    X = torch.tensor(X, dtype=torch.float32); y = torch.tensor(y, dtype=torch.float32); c = torch.tensor(c, dtype=torch.long)
    Xv = torch.tensor(Xv, dtype=torch.float32); yv = torch.tensor(yv); cv = torch.tensor(cv)
    pw = torch.tensor((1 - y.mean()) / max(y.mean(), 1e-3))
    cw = torch.tensor(np.bincount(c.numpy(), minlength=len(CAUSES)) + 1.0, dtype=torch.float32)
    cw = (cw.sum() / cw) ** 0.5; cw = cw / cw.mean()
    opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=1e-4)
    for ep in range(epochs):
        perm = torch.randperm(len(X))
        for i in range(0, len(X), 256):
            idx = perm[i:i + 256]
            s, cl = net(X[idx])
            loss = Fnn.binary_cross_entropy_with_logits(s, y[idx], pos_weight=pw) + Fnn.cross_entropy(cl, c[idx], weight=cw)
            opt.zero_grad(); loss.backward(); opt.step()
        if ep % 10 == 9 or ep == epochs - 1:
            with torch.no_grad():
                s, cl = net(Xv)
                p = torch.sigmoid(s).numpy(); acc = (cl.argmax(-1) == cv).float().mean().item()
                from sklearn.metrics import roc_auc_score
                auc = roc_auc_score(yv.numpy(), p) if 0 < yv.float().mean() < 1 else np.nan
            log(f"REFL ep{ep} val AUC={auc:.3f} cause-acc={acc:.3f}")
    return net
