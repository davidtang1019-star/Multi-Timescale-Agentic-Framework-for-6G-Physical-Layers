"""Experiments E1-E5 on test sets A (in-distribution), B (distribution shift), C (adversarial)."""
from __future__ import annotations

import json
import os
import pickle
import sys
import time
from multiprocessing import get_context

import numpy as np
import torch

from actions import POWER_DB
from agent import Method, Models, cycle_reference, run_episode
from memory import mem_feat_dim, probe, SemanticMemory
from models import IntentEncoder, PolicyNet, ReflectionNet, policy_input_dim, CAUSES
from scenarios import POSITIVE, Episode, make_spec
from triggers import event_metrics

OUT = os.environ.get("VILA_OUT", "/home/claude/work/results")
N_SEEDS = int(os.environ.get("VILA_SEEDS", 20))
T_EP = 300
SEED_BASE = {"A": 1000, "B": 2000, "C": 3000}

METHODS = [
    Method("AGENS-Open", generator="nomem", trigger="every", envelope="none"),
    Method("AGENS-Open+Env", generator="nomem", trigger="every", envelope="mask"),
    Method("AGENS-OLLA", generator="nomem", trigger="every", envelope="mask", olla=True),
    Method("AGENS-Fixed", generator="nomem", trigger="fixed", envelope="mask", period=10),
    Method("AGENS-StatOnly", generator="mem", trigger="stat"),
    Method("AGENS-Stat+Rule", generator="mem", trigger="statrule"),
    Method("AGENS-SemOnly", generator="mem", trigger="sem"),
    Method("Greedy-Replan", generator="greedy", trigger="fusion"),
    Method("Beam-Replan", generator="beam", trigger="fusion"),
    Method("VILA", generator="mem", trigger="fusion"),
    # ablations
    Method("VILA-noMem", generator="nomem", trigger="fusion"),
    Method("VILA-Fixed", generator="mem", trigger="fixed", period=10),
    Method("VILA-noCooldown", generator="mem", trigger="fusion", cooldown=0),
    Method("VILA-noInvalidate", generator="mem", trigger="fusion", invalidate=False),
    Method("VILA-Gated", generator="mem", trigger="fusion", gated=True),
    Method("VILA-PostHoc", generator="mem", trigger="fusion", envelope="posthoc"),
    Method("VILA-Project", generator="mem", trigger="fusion", envelope="project"),
    Method("VILA-Unguarded", generator="mem", trigger="fusion", envelope="none"),
    Method("Oracle", generator="oracle", trigger="every"),
]

_MODELS = None


def load_models() -> Models:
    enc = IntentEncoder().fit()
    pm = PolicyNet(policy_input_dim(mem_feat_dim(4))); pm.load_state_dict(torch.load(os.path.join(OUT, "policy_mem.pt"))); pm.eval()
    pn = PolicyNet(policy_input_dim(0)); pn.load_state_dict(torch.load(os.path.join(OUT, "policy_nomem.pt"))); pn.eval()
    rf = ReflectionNet(); rf.load_state_dict(torch.load(os.path.join(OUT, "reflection.pt"))); rf.eval()
    calib = json.load(open(os.path.join(OUT, "calib.json")))
    return Models(enc, pm, pn, rf, calib)


def recovery_delays(log, spec, cap=30):
    out = []
    sat = log["sat"]
    for e in spec.events:
        if e.kind != "intent":
            continue
        t0 = int(e.t); d = cap
        for t in range(t0, min(len(sat), t0 + cap)):
            if sat[t]:
                d = t - t0; break
        out.append(d)
    return out


def episode_metrics(log, spec, T):
    trig_t = [t for t in np.flatnonzero(log["trigger"]) if t > 0]
    ev = sorted({int(e.t) for e in spec.events if e.kind in POSITIVE})
    m = event_metrics(trig_t, ev, T)
    per_type = {}
    for kind in ("regime", "blockage", "intent"):
        evk = [int(e.t) for e in spec.events if e.kind == kind]
        if evk:
            mk = event_metrics(trig_t, evk, T)
            per_type[kind] = (mk["detected"], mk["n_events"])
    neg = {}
    for kind in ("transient", "restate"):
        evk = [int(e.t) for e in spec.events if e.kind == kind]
        fired = sum(1 for e in evk if any(e <= t <= e + 2 for t in trig_t))
        neg[kind] = (fired, len(evk))
    rec = recovery_delays(log, spec)
    reg_after = []
    for e in ev:
        reg_after.append(float(np.sum(log["regret"][e:e + 10])))
    reg_int = [float(np.sum(log["regret"][int(e.t):int(e.t) + 20])) for e in spec.events if e.kind == "intent"]
    sat_int = [float(np.mean(log["sat"][int(e.t):int(e.t) + 20])) for e in spec.events if e.kind == "intent"]
    ctx = log["ctx_tokens"][log["ctx_tokens"] > 0]
    # attribution accuracy on reflection calls inside event windows
    attr = []
    for e in spec.events:
        if e.kind in ("regime", "blockage", "intent", "transient"):
            t0 = int(e.t) if e.kind == "intent" else int(e.t) + 1
            for t in range(t0, min(T, t0 + 2)):
                if log["refl_called"][t]:
                    attr.append(int(log["cause"][t] == e.kind))
    return {
        "cum_reward": float(np.sum(log["reward"])), "mean_reward": float(np.mean(log["reward"])),
        "cum_regret": float(np.sum(log["regret"])), "sat": float(np.mean(log["sat"])),
        "switch100": 100 * float(np.mean(log["switch"][1:])), "replan100": 100 * float(np.mean(log["replan"][1:])),
        "refl100": 100 * float(np.mean(log["refl_called"][1:])), "gen100": 100 * float(np.mean(log["gen_calls"][1:])),
        "evals100": 100 * float(np.mean(log["evals"][1:])),
        "viol_rate": float(np.mean(log["violation"])), "raw_infeasible": float(np.sum(log["raw_infeasible"])) / max(1, float(np.sum(log["gen_calls"]))),
        "projected": float(np.sum(log["projected"])),
        "precision": m["precision"], "recall": m["recall"], "f1": m["f1"], "fpr": m["fpr"], "delay": m["delay"],
        "tp": m["tp"], "n_trig": m["n_trig"], "detected": m["detected"], "n_events": m["n_events"], "fp": m["fp"],
        "per_type": per_type, "neg": neg, "recovery": rec, "regret_after_event": reg_after,
        "ctx_mean": float(ctx.mean()) if len(ctx) else 0.0, "ctx_max": float(ctx.max()) if len(ctx) else 0.0,
        "attr": attr, "regret_after_intent": reg_int, "sat_after_intent": sat_int,
    }


def run_one(args):
    S, seed, method_names, keep_traj = args
    global _MODELS
    if _MODELS is None:
        torch.set_num_threads(1)
        _MODELS = load_models()
    sd = SEED_BASE[S] + seed
    spec = make_spec(S, T_EP, np.random.default_rng(sd))
    ep = Episode(spec, sd)
    refs = [cycle_reference(c) for c in ep.cycles]
    res = {}
    traj = {}
    for M in METHODS:
        if method_names and M.name not in method_names:
            continue
        t0 = time.time()
        log = run_episode(ep, M, _MODELS, refs, record_text=(keep_traj and M.name == "VILA"))
        met = episode_metrics(log, spec, T_EP)
        met["wall"] = time.time() - t0
        res[M.name] = met
        if keep_traj:
            traj[M.name] = {k: log[k] for k in ("reward", "oracle", "sat", "trigger", "s", "p", "lam", "cp", "intent", "regret", "switch")}
            if M.name == "VILA":
                traj["VILA_texts"] = log["texts"][:6]; traj["VILA_summary"] = log["mem_summary"]
                traj["VILA_causes"] = log["cause"]
    meta = {"events": [(int(e.t), e.kind) for e in spec.events], "regimes": spec.regimes, "intents": [(int(a), b, c) for a, b, c in spec.intents],
            "caps": spec.caps}
    return S, seed, res, traj, meta


def main():
    sets = sys.argv[1].split(",") if len(sys.argv) > 1 else ["A", "B", "C"]
    procs = int(os.environ.get("VILA_PROCS", 2))
    jobs = [(S, s, None, s < 2) for S in sets for s in range(N_SEEDS)]
    t0 = time.time()
    results = {S: {} for S in sets}; trajs = {}; metas = {}
    with get_context("spawn").Pool(procs) as pool:
        for S, seed, res, traj, meta in pool.imap_unordered(run_one, jobs):
            results[S][seed] = res; metas[(S, seed)] = meta
            if traj:
                trajs[(S, seed)] = traj
            print(f"{S} seed {seed} done ({time.time()-t0:.0f}s)", flush=True)
    tag = "_".join(sets)
    pickle.dump({"results": results, "trajs": trajs, "metas": metas}, open(os.path.join(OUT, f"exp_{tag}.pkl"), "wb"))
    print("saved", flush=True)


if __name__ == "__main__":
    main()
