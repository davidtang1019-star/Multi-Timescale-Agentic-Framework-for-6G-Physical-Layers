import os, numpy as np, torch
from train import OUT, collect_rollouts
from run_experiments import load_models
from models import train_reflection
m = load_models(); m.refl = None
ro = collect_rollouts("train", 60, 150, 200000, m)
Xr = np.concatenate([r["log"]["xr"] for r in ro]); yr = np.concatenate([r["y"] for r in ro]); cr = np.concatenate([r["cause"] for r in ro])
nvr = len(Xr) // 6
logf = open(os.path.join(OUT, "train_log.txt"), "a")
def log(s): print(s); logf.write(s + "\n")
log("--- reflection retrained without leaky timing features, events_noisy behaviour policy")
refl = train_reflection(Xr[nvr:], yr[nvr:], cr[nvr:], Xr[:nvr], yr[:nvr], cr[:nvr], log=log)
torch.save(refl.state_dict(), os.path.join(OUT, "reflection.pt"))
