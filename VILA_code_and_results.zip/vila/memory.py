"""Hierarchical semantic memory: raw short-term buffer + recursive long-term summary.

Text serialisation is real and token counts use the exact GPT-2 byte-level BPE vocabulary
(encoder.json / vocab.bpe), i.e. the tokenizer of the GPT-2 Medium backbone used by AGENS.
"""
from __future__ import annotations

import os
import re
from collections import Counter, deque
from dataclasses import dataclass, field
from typing import Deque, List, Optional

import numpy as np

from actions import CODE_NAMES, MOD_NAMES, POWER_DB, RATE_NAMES, action_text, spectral_eff
from linksim import INTENT_NAMES

_TOK = None


def tokenizer():
    global _TOK
    if _TOK is None:
        from tokenizers import ByteLevelBPETokenizer
        d = os.environ.get("GPT2_BPE_DIR", "/home/claude/work/tok/package")
        _TOK = ByteLevelBPETokenizer(os.path.join(d, "encoder.json"), os.path.join(d, "vocab.bpe"))
    return _TOK


def n_tokens(text: str) -> int:
    return len(tokenizer().encode(text).ids)


@dataclass
class Tuple_:
    t: int
    action: tuple
    ber: float
    frac: float
    rate: float
    snr_rep: float
    intent: int
    epoch: int          # memory epoch (incremented on attributed regime switch / intent drift)
    cause: str = "none"


def entry_text(e: Tuple_) -> str:
    return (f"[t={e.t}] act: {action_text(e.action)} | obs: BER={e.ber:.1e} (fail {int(round(e.frac*10))}/10), "
            f"rate={e.rate:.2f} b/RE | SNR={e.snr_rep:.1f} dB")


@dataclass
class SemanticMemory:
    W: int = 4                    # short-term buffer length
    summary_budget: int = 150     # long-term summary budget [tokens]
    context_budget: int = 1024
    buf: Deque[Tuple_] = field(default_factory=deque)
    intent_runs: List[list] = field(default_factory=list)  # [intent, t_start]
    switches: List[list] = field(default_factory=list)     # [t, cause]
    failures: Counter = field(default_factory=Counter)
    epoch: int = 0
    regime_feat: Optional[np.ndarray] = None               # EWMA of CSI descriptors in current epoch
    ewma_frac: float = 0.0
    ewma_snr: Optional[float] = None
    n_since_epoch: int = 0
    last_intent_probs: Optional[np.ndarray] = None
    summary_regens: int = 0

    # -------------------------------------------------------------- updates
    def push(self, e: Tuple_):
        e.epoch = self.epoch
        self.buf.append(e)
        while len(self.buf) > self.W:
            old = self.buf.popleft()
            self._absorb(old)
        self.ewma_frac = 0.8 * self.ewma_frac + 0.2 * e.frac
        self.ewma_snr = e.snr_rep if self.ewma_snr is None else 0.8 * self.ewma_snr + 0.2 * e.snr_rep
        self.n_since_epoch += 1

    def _absorb(self, e: Tuple_):
        if e.frac > 0:
            mode = self.failure_mode(e)
            self.failures[mode] += 1

    @staticmethod
    def failure_mode(e: Tuple_) -> str:
        se = spectral_eff(e.action)
        if se >= 4.0:
            return "high-order MCS failure"
        if e.action[2] <= 1 and se < 2:
            return "low-power failure"
        return "robust-MCS failure"

    def note_intent(self, intent: int, t: int):
        if not self.intent_runs or self.intent_runs[-1][0] != intent:
            self.intent_runs.append([intent, t])

    def new_epoch(self, t: int, cause: str):
        """Cause-aware invalidation: tuples gathered before an attributed regime switch / blockage
        no longer describe the channel and are moved to the long-term store."""
        self.switches.append([t, cause])
        self.epoch += 1
        if cause in ("regime", "blockage"):
            while self.buf:
                self._absorb(self.buf.popleft())
            self.ewma_frac = 0.0; self.ewma_snr = None; self.regime_feat = None
        self.n_since_epoch = 0

    def update_regime_feat(self, f: np.ndarray):
        self.regime_feat = f.copy() if self.regime_feat is None else 0.85 * self.regime_feat + 0.15 * f

    # -------------------------------------------------------------- text views
    def summary_text(self, budget: Optional[int] = None) -> str:
        budget = self.summary_budget if budget is None else budget
        runs = list(self.intent_runs); sw = list(self.switches); fm = self.failures.most_common()
        n_changes = max(0, len(self.intent_runs) - 1)

        def render(runs, sw, fm):
            r = " -> ".join(f"{INTENT_NAMES[i]}@{t}" for i, t in runs) or "none"
            s = ", ".join(f"{c}@{t}" for t, c in sw) or "none"
            f = ", ".join(f"{m} x{c}" for m, c in fm) or "none"
            return (f"[Summary] intent changes={n_changes}; intents: {r}. switch points: {s}. "
                    f"recurring failures: {f}.")
        txt = render(runs, sw, fm)
        # recursive compression: drop oldest items until the budget is met
        while n_tokens(txt) > budget and (len(runs) > 2 or len(sw) > 1 or len(fm) > 1):
            if len(runs) > 2:
                runs = runs[1:]
            elif len(sw) > 1:
                sw = sw[1:]
            else:
                fm = fm[:1]
            txt = render(runs, sw, fm)
        return txt

    def buffer_text(self) -> str:
        return "\n".join(entry_text(e) for e in self.buf)

    def context(self, intent_text: str, constraint_text: str, n_csi_tokens: int = 0) -> str:
        return (f"[Intent] {intent_text}\n[Constraints] {constraint_text}\n{self.summary_text()}\n"
                f"[Recent]\n{self.buffer_text()}")

    def context_tokens(self, intent_text: str, constraint_text: str) -> int:
        return n_tokens(self.context(intent_text, constraint_text))

    # -------------------------------------------------------------- numeric view for compact backbone
    def features(self) -> np.ndarray:
        """Short-term buffer (W x 8) + long-term summary features (8)."""
        rows = []
        items = list(self.buf)[-self.W:]
        for e in items:
            rows.append([1.0, e.snr_rep / 10, spectral_eff(e.action) / 8, POWER_DB[e.action[2]] / 8,
                         e.frac, np.log10(e.ber + 1e-7) / 7 + 1, e.rate / 5, float(e.action[3] == 0)])
        while len(rows) < self.W:
            rows.insert(0, [0.0] * 8)
        tot = sum(self.failures.values()) + 1e-9
        lt = [min(self.n_since_epoch, 50) / 50, min(len(self.switches), 5) / 5, self.ewma_frac,
              self.failures["high-order MCS failure"] / tot if tot > 1 else 0.0,
              self.failures["robust-MCS failure"] / tot if tot > 1 else 0.0,
              min(len(self.intent_runs), 6) / 6, (self.ewma_snr or 0.0) / 10, float(len(self.buf) > 0)]
        return np.concatenate([np.array(rows, dtype=np.float32).reshape(-1), np.array(lt, dtype=np.float32)])


def mem_feat_dim(W: int) -> int:
    return 8 * W + 8


# ------------------------------------------------------------------ memory probes

def probe(summary: str, truth: dict) -> dict:
    """Multiple-choice style probe answered by parsing the summary text only."""
    res = {}
    m = re.search(r"intent changes=(\d+)", summary)
    res["n_changes"] = bool(m) and int(m.group(1)) == truth["n_changes"]
    ints = re.findall(r"([a-z+\-]+)@(\d+)", summary.split("switch points")[0])
    names = [n for n, _ in ints]
    res["prev_intent"] = len(names) >= 2 and names[-2] == truth["prev_intent"] if truth["prev_intent"] else True
    sw = re.findall(r"(regime|blockage|intent)@(\d+)", summary.split("switch points:")[1].split(".")[0]) if "switch points:" in summary else []
    reg_sw = [int(t) for c, t in sw if c in ("regime", "blockage")]
    res["last_switch"] = (truth["last_switch"] is None) or (len(reg_sw) > 0 and abs(reg_sw[-1] - truth["last_switch"]) <= 2)
    fm = re.search(r"recurring failures: ([^.]*)", summary)
    top = fm.group(1).split(" x")[0] if fm else ""
    res["top_failure"] = (truth["top_failure"] is None) or (top == truth["top_failure"])
    return res
