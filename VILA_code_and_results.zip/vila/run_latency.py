"""E5b: effect of generator inference latency (decisions take effect D cycles later)."""
import os, pickle, sys, time
import numpy as np
from multiprocessing import get_context
import run_experiments as RE
from agent import Method, run_episode, cycle_reference
from scenarios import make_spec, Episode

DS = [0, 2, 6, 33]
def methods():
    out = []
    for D in DS:
        out += [Method(f"AGENS-Open+Env|{D}", generator="nomem", trigger="every", envelope="mask", latency=D),
                Method(f"AGENS-Fixed|{D}", generator="nomem", trigger="fixed", period=max(10, D + 1), latency=D),
                Method(f"VILA|{D}", generator="mem", trigger="fusion", latency=D),
                Method(f"VILA-noMem|{D}", generator="nomem", trigger="fusion", latency=D)]
    return out

def job(args):
    S, seed = args
    import torch; torch.set_num_threads(1)
    if RE._MODELS is None:
        RE._MODELS = RE.load_models()
    sd = RE.SEED_BASE[S] + seed
    spec = make_spec(S, RE.T_EP, np.random.default_rng(sd)); ep = Episode(spec, sd)
    refs = [cycle_reference(c) for c in ep.cycles]
    res = {}
    for M in methods():
        log = run_episode(ep, M, RE._MODELS, refs)
        res[M.name] = RE.episode_metrics(log, spec, RE.T_EP)
    return S, seed, res

if __name__ == "__main__":
    jobs = [(S, s) for S in ("A", "B") for s in range(20)]
    R = {"A": {}, "B": {}}
    with get_context("spawn").Pool(2) as pool:
        for S, seed, res in pool.imap_unordered(job, jobs):
            R[S][seed] = res; print(S, seed, flush=True)
    pickle.dump(R, open(os.path.join(RE.OUT, "exp_latency.pkl"), "wb"))
    print("saved")
