"""E2 sensitivity (+-20% on CUSUM h and fusion tau) and E5 memory-budget probes / timing."""
import copy, json, os, pickle, time
import numpy as np
import run_experiments as RE
from agent import Method, run_episode, cycle_reference
from memory import probe, n_tokens, entry_text
from scenarios import make_spec, Episode
from triggers import event_metrics
from scenarios import POSITIVE

models = RE.load_models()
base = copy.deepcopy(models.calib)
eps = []
for s in range(10):
    sd = RE.SEED_BASE["A"] + s
    spec = make_spec("A", RE.T_EP, np.random.default_rng(sd)); ep = Episode(spec, sd)
    eps.append((spec, ep, [cycle_reference(c) for c in ep.cycles]))
out = {"sens": [], "probe": [], "timing": {}}
for fh in (0.8, 0.9, 1.0, 1.1, 1.2):
    for ft in (0.8, 0.9, 1.0, 1.1, 1.2):
        cal = copy.deepcopy(base); cal["cusum_h"] = base["cusum_h"] * fh; cal["fusion"]["tau"] = min(0.999, base["fusion"]["tau"] * ft)
        models.calib = cal
        tp = nt = det = ne = 0; fpr = []; reg = []
        for spec, ep, refs in eps:
            log = run_episode(ep, Method("VILA"), models, refs)
            trig = [t for t in np.flatnonzero(log["trigger"]) if t > 0]
            m = event_metrics(trig, sorted({int(e.t) for e in spec.events if e.kind in POSITIVE}), RE.T_EP)
            tp += m["tp"]; nt += m["n_trig"]; det += m["detected"]; ne += m["n_events"]; fpr.append(m["fpr"]); reg.append(log["regret"].sum())
        p = tp / nt if nt else 0; r = det / ne
        out["sens"].append({"fh": fh, "ft": ft, "f1": 2 * p * r / (p + r) if p + r else 0, "precision": p, "recall": r, "fpr": float(np.mean(fpr)), "regret": float(np.mean(reg))})
        print(out["sens"][-1], flush=True)
models.calib = base
# ---- memory probes vs summary budget (end-of-episode memories of VILA on test set A and C)
for S in ("A", "C"):
    for s in range(20):
        sd = RE.SEED_BASE[S] + s
        spec = make_spec(S, RE.T_EP, np.random.default_rng(sd)); ep = Episode(spec, sd)
        refs = [cycle_reference(c) for c in ep.cycles]
        log = run_episode(ep, Method("VILA"), models, refs)
        mem = log["mem"]
        ints = [i for _, i, _ in sorted(spec.intents)]
        runs = [ints[0]] + [b for a, b in zip(ints, ints[1:]) if b != a]
        from linksim import INTENT_NAMES
        regs = [int(e.t) for e in spec.events if e.kind in ("regime", "blockage")]
        mem_full = mem.summary_text(budget=10 ** 6)
        top = mem.failures.most_common(1)[0][0] if mem.failures else None
        truth = {"n_changes": max(0, len(mem.intent_runs) - 1), "prev_intent": INTENT_NAMES[mem.intent_runs[-2][0]] if len(mem.intent_runs) > 1 else None,
                 "last_switch": regs[-1] if regs else None, "top_failure": top}
        truth_world = {"n_changes_true": len(runs) - 1}
        for B in (40, 60, 80, 100, 150, 250, 10 ** 6):
            txt = mem.summary_text(budget=B)
            pr = probe(txt, truth)
            out["probe"].append({"set": S, "seed": s, "budget": B, "tokens": n_tokens(txt), **pr,
                                 "n_changes_world_match": truth["n_changes"] == truth_world["n_changes_true"]})
# ---- timing of non-LLM components (CPU, single thread)
import torch; torch.set_num_threads(1)
from actions import masked_decode, project, EnvelopeState, all_actions
from triggers import CUSUM, BOCPD
e = EnvelopeState(3, False); rng = np.random.default_rng(0)
lg = [rng.normal(size=d) for d in (4, 5, 7, 3, 3, 3, 2)]
def tm(f, n=2000):
    t0 = time.perf_counter()
    for _ in range(n): f()
    return (time.perf_counter() - t0) / n * 1e6
c = CUSUM(sigma=np.ones(3)); b = BOCPD()
for _ in range(200): c.update(rng.normal(size=3)); b.update(rng.normal())
x_ref = np.zeros(16, dtype=np.float32); x_pol = np.zeros(74, dtype=np.float32)
out["timing"] = {"masked_decode_us": tm(lambda: masked_decode(lg, e)), "project_us": tm(lambda: project((3, 4, 6, 2, 2, 0, 0), e), 500),
                 "cusum_us": tm(lambda: c.update(rng.normal(size=3))), "bocpd_us": tm(lambda: b.update(rng.normal())),
                 "reflection_net_us": tm(lambda: models.refl.predict(x_ref)), "policy_net_us": tm(lambda: models.pol_mem.logits_np(x_pol))}
print(out["timing"])
json.dump(out, open(os.path.join(RE.OUT, "e2_e5.json"), "w"), indent=1, default=float)
print("saved")
