"""Statistics, tables and figures for the paper."""
from __future__ import annotations

import json
import os
import pickle
import sys

import numpy as np
from scipy import stats

OUT = os.environ.get("VILA_OUT", "/home/claude/work/results")
FIG = os.environ.get("VILA_FIG", "/home/claude/work/paper/figs")
os.makedirs(FIG, exist_ok=True)

MAIN = ["AGENS-Open", "AGENS-Open+Env", "AGENS-OLLA", "AGENS-Fixed", "AGENS-StatOnly", "AGENS-Stat+Rule", "AGENS-SemOnly",
        "Greedy-Replan", "Beam-Replan", "VILA"]
ABL = ["VILA", "VILA-noMem", "VILA-Fixed", "VILA-noCooldown", "VILA-noInvalidate", "VILA-Gated", "VILA-PostHoc", "VILA-Project", "VILA-Unguarded"]


def load():
    d = pickle.load(open(os.path.join(OUT, "exp_A_B_C.pkl"), "rb"))
    return d


def arr(R, S, m, key):
    return np.array([R[S][s][m][key] for s in sorted(R[S])], dtype=float)


def ci(x):
    x = np.asarray(x, dtype=float); x = x[np.isfinite(x)]
    n = len(x)
    if n < 2:
        return float(np.mean(x)) if n else np.nan, np.nan
    h = stats.t.ppf(0.975, n - 1) * x.std(ddof=1) / np.sqrt(n)
    return float(x.mean()), float(h)


def holm(pvals):
    p = np.asarray(pvals); order = np.argsort(p); m = len(p); adj = np.empty(m); run = 0
    for i, j in enumerate(order):
        run = max(run, (m - i) * p[j]); adj[j] = min(1.0, run)
    return adj


def wilcoxon(a, b, alternative="two-sided"):
    d = np.asarray(a) - np.asarray(b)
    if np.allclose(d, 0):
        return 1.0
    return float(stats.wilcoxon(a, b, alternative=alternative, zero_method="wilcox").pvalue)


def tost(a, b, margin):
    d = np.asarray(a) - np.asarray(b); n = len(d); se = d.std(ddof=1) / np.sqrt(n); m = d.mean()
    if se == 0:
        return m, 0.0, 0.0, (m, m)
    t1 = (m + margin) / se; t2 = (m - margin) / se
    p1 = 1 - stats.t.cdf(t1, n - 1); p2 = stats.t.cdf(t2, n - 1)
    h = stats.t.ppf(0.95, n - 1) * se
    return m, max(p1, p2), se, (m - h, m + h)


def pooled_trigger(R, sets, m):
    tp = nt = det = ne = 0; fpr = []; f1s = []
    for S in sets:
        for s in R[S]:
            x = R[S][s][m]; tp += x["tp"]; nt += x["n_trig"]; det += x["detected"]; ne += x["n_events"]; fpr.append(x["fpr"]); f1s.append(x["f1"])
    p = tp / nt if nt else 0; r = det / ne if ne else 0
    return {"precision": p, "recall": r, "f1": 2 * p * r / (p + r) if p + r else 0, "fpr": float(np.mean(fpr)), "f1_ep": f1s, "fpr_ep": fpr}


def per_type(R, sets, m):
    out = {}
    for kind in ("regime", "blockage", "intent"):
        d = n = 0
        for S in sets:
            for s in R[S]:
                pt = R[S][s][m]["per_type"]
                if kind in pt:
                    d += pt[kind][0]; n += pt[kind][1]
        out[kind] = d / n if n else np.nan
    for kind in ("transient", "restate"):
        d = n = 0
        for S in sets:
            for s in R[S]:
                f, k = R[S][s][m]["neg"][kind]; d += f; n += k
        out["neg_" + kind] = d / n if n else np.nan
    return out


def main():
    d = load(); R = d["results"]
    sets = ["A", "B", "C"]
    summary = {"main": {}, "abl": {}, "tests": {}, "hyp": {}, "trig": {}, "e3": {}, "e5": {}}
    keys = ["cum_regret", "mean_reward", "sat", "switch100", "replan100", "viol_rate", "f1", "fpr", "refl100", "gen100", "ctx_mean", "ctx_max", "raw_infeasible", "projected", "evals100"]
    for S in sets:
        summary["main"][S] = {}
        for m in sorted(set(MAIN + ABL + ["Oracle"])):
            summary["main"][S][m] = {k: ci(arr(R, S, m, k)) for k in keys}
            rec = [x for s in R[S] for x in R[S][s][m]["recovery"]]
            summary["main"][S][m]["recovery"] = ci(rec)
            ri = [np.sum(R[S][s][m]["regret_after_intent"]) for s in sorted(R[S])]
            summary["main"][S][m]["regret_intent"] = ci(ri)
        # Wilcoxon vs VILA with Holm
        base = [m for m in MAIN if m != "VILA"]
        pv = [wilcoxon(arr(R, S, "VILA", "cum_regret"), arr(R, S, m, "cum_regret")) for m in base]
        adj = holm(pv)
        summary["tests"][S] = {m: {"p": p, "p_holm": a, "diff": float(np.mean(arr(R, S, "VILA", "cum_regret") - arr(R, S, m, "cum_regret")))} for m, p, a in zip(base, pv, adj)}
        pv2 = [wilcoxon(arr(R, S, "VILA", "cum_regret"), arr(R, S, m, "cum_regret")) for m in ABL[1:]]
        adj2 = holm(pv2)
        summary["tests"][S + "_abl"] = {m: {"p": p, "p_holm": a} for m, p, a in zip(ABL[1:], pv2, adj2)}
    # ---------------- H1
    v = np.array([np.sum(R["A"][s]["VILA"]["regret_after_intent"]) for s in sorted(R["A"])])
    f = np.array([np.sum(R["A"][s]["AGENS-Fixed"]["regret_after_intent"]) for s in sorted(R["A"])])
    red = 1 - v.mean() / f.mean()
    p_reg = wilcoxon(v, f, "less")
    sw_v = arr(R, "A", "VILA", "switch100"); sw_f = arr(R, "A", "AGENS-Fixed", "switch100")
    p_sw = wilcoxon(sw_v, sw_f, "greater")
    whole = 1 - arr(R, "A", "VILA", "cum_regret").mean() / arr(R, "A", "AGENS-Fixed", "cum_regret").mean()
    # bootstrap CI of reduction
    rng = np.random.default_rng(0); bs = []
    for _ in range(5000):
        i = rng.integers(0, len(v), len(v)); bs.append(1 - v[i].mean() / f[i].mean())
    summary["hyp"]["H1"] = {"reduction_intent_windows": red, "red_ci": [float(np.quantile(bs, .025)), float(np.quantile(bs, .975))],
                            "p_regret_less": p_reg, "switch_vila": ci(sw_v), "switch_fixed": ci(sw_f), "p_switch_greater": p_sw,
                            "reduction_whole": whole, "pass": bool(red >= 0.25 and p_sw >= 0.05)}
    # mem-only contrast (same trigger): VILA vs VILA-noMem / VILA-Fixed
    for other in ("VILA-noMem", "VILA-Fixed", "AGENS-Open+Env"):
        o = np.array([np.sum(R["A"][s][other]["regret_after_intent"]) for s in sorted(R["A"])])
        summary["hyp"]["H1_vs_" + other] = {"reduction": 1 - v.mean() / o.mean(), "p": wilcoxon(v, o)}
    # ---------------- H2
    trig = {}
    for m in ("VILA", "AGENS-StatOnly", "AGENS-SemOnly", "AGENS-Stat+Rule", "VILA-Gated", "VILA-noCooldown"):
        trig[m] = {S: pooled_trigger(R, [S], m) for S in sets}
        trig[m]["AB"] = pooled_trigger(R, ["A", "B"], m)
        trig[m]["types_AB"] = per_type(R, ["A", "B"], m)
        trig[m]["types_C"] = per_type(R, ["C"], m)
    fu = trig["VILA"]["AB"]; best_single = max(trig["AGENS-StatOnly"]["AB"]["f1"], trig["AGENS-SemOnly"]["AB"]["f1"])
    p_f1_sem = wilcoxon(fu["f1_ep"], trig["AGENS-SemOnly"]["AB"]["f1_ep"])
    p_f1_stat = wilcoxon(fu["f1_ep"], trig["AGENS-StatOnly"]["AB"]["f1_ep"])
    summary["hyp"]["H2"] = {"f1_fusion": fu["f1"], "f1_best_single": best_single, "rel_gain": fu["f1"] / best_single - 1,
                            "fpr_fusion": fu["fpr"], "p_vs_sem": p_f1_sem, "p_vs_stat": p_f1_stat,
                            "pass": bool(fu["f1"] / best_single - 1 >= 0.15 and fu["fpr"] < 0.05)}
    summary["trig"] = {m: {k: (v if k.startswith("types") else {kk: vv for kk, vv in v.items() if kk not in ("f1_ep", "fpr_ep")}) for k, v in t.items()} for m, t in trig.items()}
    # ---------------- H3 (TOST), per set and pooled
    h3 = {}
    allv, allp = [], []
    for S in sets:
        a = arr(R, S, "VILA", "mean_reward"); b = arr(R, S, "VILA-PostHoc", "mean_reward")
        margin = 0.02 * abs(b.mean())
        mdiff, p, se, ci90 = tost(a, b, margin)
        h3[S] = {"diff": mdiff, "p_tost": p, "margin": margin, "ci90": ci90, "equiv": bool(p < 0.05)}
        allv.append(a); allp.append(b)
    a = np.concatenate(allv); b = np.concatenate(allp); margin = 0.02 * abs(b.mean())
    mdiff, p, se, ci90 = tost(a, b, margin)
    h3["pooled"] = {"diff": mdiff, "p_tost": p, "margin": margin, "ci90": ci90, "equiv": bool(p < 0.05)}
    for other in ("VILA-Project", "VILA-Unguarded"):
        for S in sets:
            a = arr(R, S, "VILA", "mean_reward"); b = arr(R, S, other, "mean_reward")
            h3[f"{other}_{S}"] = {"diff": float(np.mean(a - b)), "p_wilcoxon": wilcoxon(a, b)}
    summary["hyp"]["H3"] = h3
    # ---------------- E3 degradation A->B (per-cycle regret)
    for m in MAIN + ["VILA-noMem"]:
        rA = arr(R, "A", m, "cum_regret") / 300; rB = arr(R, "B", m, "cum_regret") / 300
        summary["e3"][m] = {"regret_A": ci(rA), "regret_B": ci(rB), "sat_A": ci(arr(R, "A", m, "sat")), "sat_B": ci(arr(R, "B", m, "sat"))}
    attr = {S: [x for s in R[S] for x in R[S][s]["VILA"]["attr"]] for S in sets}
    summary["e3"]["attribution_acc"] = {S: (float(np.mean(v)) if v else np.nan, len(v)) for S, v in attr.items()}
    json.dump(summary, open(os.path.join(OUT, "summary.json"), "w"), indent=1, default=float)
    print(json.dumps(summary["hyp"], indent=1, default=float))
    return summary


if __name__ == "__main__":
    main()
