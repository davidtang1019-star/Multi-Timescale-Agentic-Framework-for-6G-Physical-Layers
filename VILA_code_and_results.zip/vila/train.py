"""Stage 1: data generation and training of the policy generators and the reflection scorer.
Stage 2: calibration of CUSUM / BOCPD parameters and of the fusion triggers."""
from __future__ import annotations

import json
import os
import pickle
import sys
import time
from multiprocessing import Pool

import numpy as np
import torch

from actions import EnvelopeState, feasible_tensor, flat_index, project, unflat
from agent import Method, Models, cycle_reference, run_episode
from linksim import TRAIN_REGIMES
from memory import SemanticMemory, Tuple_, mem_feat_dim
from models import (CAUSES, IntentEncoder, js_div, train_policy, train_reflection)
from scenarios import POSITIVE, TRAIN_TEXTS, Episode, EpisodeSpec, make_spec
from triggers import CUSUM, BOCPD, event_metrics

OUT = os.environ.get("VILA_OUT", "/home/claude/work/results")
W = 4
ENC = None
SCALE = float(os.environ.get("VILA_SCALE", 1.0))


def _perturb(a, rng):
    a = list(a)
    for k, lim in ((0, 3), (1, 4), (2, 6)):
        if rng.uniform() < 0.5:
            a[k] = int(np.clip(a[k] + rng.integers(-2, 3), 0, lim))
    for k, d in ((3, 3), (4, 3), (5, 3), (6, 2)):
        if rng.uniform() < 0.3:
            a[k] = int(rng.integers(d))
    return tuple(a)


def gen_sample(seed: int):
    global ENC
    if ENC is None:
        ENC = IntentEncoder().fit()
    rng = np.random.default_rng(seed)
    reg = TRAIN_REGIMES[int(rng.integers(len(TRAIN_REGIMES)))]
    intent = int(rng.integers(3)); text = TRAIN_TEXTS[intent][int(rng.integers(4))]
    caps = [(W, W + 1, int(rng.integers(0, 6)))] if rng.uniform() < 0.15 else []
    spec = EpisodeSpec(W + 1, [(0, reg)], [(0, intent, text)], [], [], caps, float(rng.uniform(-5, 5)))
    ep = Episode(spec, seed, cov_invalid_from=W if rng.uniform() < 0.15 else 10 ** 9)
    mem = SemanticMemory(W=W)
    beh_intent = intent if rng.uniform() > 0.3 else int(rng.integers(3))
    hold = rng.uniform() < 0.5
    n_valid = int(rng.integers(0, W + 1)) if rng.uniform() < 0.3 else W
    a_hold = None
    probs = ENC.probs(text)
    for t in range(W):
        c = ep.cycles[t]
        from linksim import reward_for_intent
        r = reward_for_intent(c.tables, beh_intent).reshape(-1)
        F = feasible_tensor(c.env).reshape(-1)
        a0 = unflat(int(np.argmax(np.where(F, r, -np.inf))))
        a = a_hold if (hold and a_hold is not None) else project(_perturb(a0, rng), c.env)[0]
        a_hold = a
        i = flat_index(a)
        if t >= W - n_valid:
            mem.push(Tuple_(t, a, float(c.tables["ber_obs"].reshape(-1)[i]), float(c.tables["frac"].reshape(-1)[i]),
                            float(c.tables["rate_obs"].reshape(-1)[i]), float(c.feat[24] * 10), intent, 0))
        mem.update_regime_feat(c.feat); mem.note_intent(int(np.argmax(probs)), t)
    cW = ep.cycles[W]
    F = feasible_tensor(cW.env).reshape(-1)
    R = cW.tables["reward"].reshape(-1)
    y = unflat(int(np.argmax(np.where(F, R, -np.inf))))
    feat = ep.cycles[W - 1].feat
    x_base = np.concatenate([feat, probs.astype(np.float32), np.array([cW.env.cap_idx / 6, float(cW.env.cov_valid)], np.float32)])
    return x_base.astype(np.float32), mem.features(), np.array(y), R.astype(np.float16), F


def gen_policy_data(n, seed0, procs=2):
    import multiprocessing as mp
    with mp.get_context("spawn").Pool(procs) as pool:
        res = pool.map(gen_sample, range(seed0, seed0 + n), chunksize=64)
    Xb = np.stack([r[0] for r in res]); M = np.stack([r[1] for r in res]); Y = np.stack([r[2] for r in res])
    R = np.stack([r[3] for r in res]); F = np.stack([r[4] for r in res])
    return Xb, M, Y, R, F


# ----------------------------------------------------------------------------- reflection data
def cycle_labels(spec, T):
    y = np.zeros(T, dtype=np.float32); cause = np.zeros(T, dtype=np.int64)
    for e in sorted(spec.events, key=lambda e: e.t):
        t0 = int(e.t) if e.kind in ("intent", "restate") else int(e.t) + 1
        L = 3 if e.kind in POSITIVE else (int(e.info.get("dur", 1)) + 1 if e.kind == "transient" else 3)
        for t in range(t0, min(T, t0 + L)):
            if e.kind in POSITIVE:
                y[t] = 1.0
            cause[t] = CAUSES.index(e.kind) if e.kind in CAUSES else 0
    return y, cause


def collect_rollouts(kind, n_ep, T, seed0, models: Models, procs=1):
    out = []
    for k in range(n_ep):
        sd = seed0 + k
        spec = make_spec(kind, T, np.random.default_rng(sd))
        ep = Episode(spec, sd)
        refs = [cycle_reference(c) for c in ep.cycles]
        log = run_episode(ep, Method("collect", generator="mem", trigger="events_noisy"), models, refs)
        y, cause = cycle_labels(spec, T)
        out.append({"spec": spec, "log": log, "y": y, "cause": cause, "replan": log["replan"]})
    return out


# ----------------------------------------------------------------------------- calibration
def offline_cusum(xk_seq, resets, k, h, sigma, warmup=2):
    c = CUSUM(k=k, h=h, sigma=np.asarray(sigma), warmup=warmup)
    lam = np.zeros(len(xk_seq))
    for t, x in enumerate(xk_seq):
        if resets[t]:
            c.reset()
        if np.all(np.isfinite(x)):
            lam[t] = c.update(x) / h
    return lam


def simulate_trigger(p, tau, cooldown=3):
    fires, last = [], -10 ** 9
    for t in range(1, len(p)):
        if p[t] > tau and t - last > cooldown:
            fires.append(t); last = t
    return fires


def event_list(spec):
    return sorted({int(e.t) for e in spec.events if e.kind in POSITIVE})


def pick_tau(P_list, specs, T, fpr_max=0.05, cooldown=3):
    best = None
    for tau in np.linspace(0.05, 0.99, 95):
        ms = [event_metrics(simulate_trigger(p, tau, cooldown), event_list(sp), T) for p, sp in zip(P_list, specs)]
        tp = sum(m["tp"] for m in ms); nt = sum(m["n_trig"] for m in ms); det = sum(m["detected"] for m in ms); ne = sum(m["n_events"] for m in ms)
        fp = sum(m["fp"] for m in ms)
        prec = tp / nt if nt else 0; rec = det / ne if ne else 0; f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0
        fpr = np.mean([m["fpr"] for m in ms])
        if fpr <= fpr_max and (best is None or f1 > best[1]):
            best = (float(tau), f1, prec, rec, fpr)
    return best


def fit_lr(X, y):
    from sklearn.linear_model import LogisticRegression
    lr = LogisticRegression(class_weight="balanced", C=1.0, max_iter=2000).fit(X, y)
    return lr.coef_[0], float(lr.intercept_[0])


def main():
    os.makedirs(OUT, exist_ok=True)
    t0 = time.time()
    logf = open(os.path.join(OUT, "train_log.txt"), "a")

    def log(m):
        print(m); logf.write(m + "\n"); logf.flush()

    enc = IntentEncoder().fit()
    # intent encoder sanity on held-out paraphrases
    from scenarios import TEST_TEXTS
    acc = {c: [int(np.argmax(enc.probs(s)) == c) for s in TEST_TEXTS[c]] for c in (0, 1, 2)}
    log("intent encoder held-out paraphrase accuracy: " + json.dumps({k: float(np.mean(v)) for k, v in acc.items()}))
    for c in (3, 4):
        log(f"intent probs class {c}: " + str([np.round(enc.probs(s), 2).tolist() for s in TEST_TEXTS[c]]))

    cache = os.path.join(OUT, "policy_data.npz")
    if os.path.exists(cache):
        d = np.load(cache); Xb, M, Y, R, F = d["Xb"], d["M"], d["Y"], d["R"], d["F"]
    else:
        Xb, M, Y, R, F = gen_policy_data(int(os.environ.get("VILA_NPOL", 24000)), 100000)
        np.savez_compressed(cache, Xb=Xb, M=M, Y=Y, R=R, F=F)
    log(f"policy data {len(Xb)} samples ({time.time()-t0:.0f}s)")
    nv = len(Xb) // 8
    idx = np.random.default_rng(0).permutation(len(Xb)); va, tr = idx[:nv], idx[nv:]
    oracleJ = float(np.mean(np.max(np.where(F[va], R[va].astype(np.float32), -9), axis=1)))
    log(f"validation oracle J={oracleJ:.4f}")
    nets = {}
    for name, use_mem in (("mem", True), ("nomem", False)):
        X = np.concatenate([Xb, M], 1) if use_mem else Xb
        log(f"--- training policy {name} (in_dim={X.shape[1]})")
        net, hist = train_policy(X[tr], Y[tr], R[tr], F[tr], X[va], Y[va], R[va], F[va], log=log, epochs_sft=max(2, int(30 * SCALE)), epochs_rl=max(1, int(15 * SCALE)))
        nets[name] = net
        torch.save(net.state_dict(), os.path.join(OUT, f"policy_{name}.pt"))
        json.dump(hist, open(os.path.join(OUT, f"policy_{name}_hist.json"), "w"))
    del R, F

    # ---------------- reflection data from oracle-triggered rollouts (training distribution)
    base_cal = {"cusum_k": 0.5, "cusum_h": 5.0, "kpi_sigma": [1.0, 0.3, 1.5], "bocpd_hazard": 0.01, "bocpd_var": 1.0,
                "stat": {"w": [0, 1, 1, 0], "b": 0, "tau": 0.5}, "sem": {"w": [1, 0, 0, 0], "b": 0, "tau": 0.5},
                "fusion": {"w": [1, 1, 1, 0], "b": 0, "tau": 0.5}}
    models = Models(enc, nets["mem"], nets["nomem"], None, base_cal)
    ro = collect_rollouts("train", max(2, int(60 * SCALE)), 150, 200000, models)
    Xr = np.concatenate([r["log"]["xr"] for r in ro]); yr = np.concatenate([r["y"] for r in ro]); cr = np.concatenate([r["cause"] for r in ro])
    nvr = len(Xr) // 6
    refl = train_reflection(Xr[nvr:], yr[nvr:], cr[nvr:], Xr[:nvr], yr[:nvr], cr[:nvr], log=log)
    torch.save(refl.state_dict(), os.path.join(OUT, "reflection.pt"))
    models.refl = refl

    # ---------------- calibration set (short sequences with injected events)
    cal_ro = collect_rollouts("calib", max(3, int(60 * SCALE)), 100, 300000, models)
    T = 100
    # KPI noise scale from event-free first differences
    diffs = []
    for r in cal_ro:
        xk = r["log"]["x_kpi"]; quiet = (r["y"] == 0)
        d = np.diff(xk, axis=0)[quiet[1:] & quiet[:-1] & ~r["replan"][1:].astype(bool)]
        diffs.append(d[np.all(np.isfinite(d), axis=1)])
    diffs = np.concatenate(diffs)
    sigma = (np.std(diffs, 0) / np.sqrt(2)).clip(0.05, None)
    log(f"KPI sigma (std of quiet first differences) = {sigma.tolist()}")
    specs = [r["spec"] for r in cal_ro]
    resets = [r["replan"].astype(bool) for r in cal_ro]
    # BOCPD on reported SNR
    bvar = float(np.var(diffs[:, 2]) / 2)
    cps = []
    for r in cal_ro:
        b = BOCPD(hazard=0.01, var=bvar); cp = np.zeros(T)
        for t in range(1, T):
            if r["replan"][t]:
                b.reset()
            x = r["log"]["x_kpi"][t]
            cp[t] = b.update(x[2]) if np.isfinite(x[2]) else 0.0
        cps.append(cp)
    # CUSUM grid scan (CUSUM alone, max F1 s.t. FPR<=5%)
    scan = []
    for k in (0.25, 0.5, 1.0, 1.5, 2.0, 3.0):
        for h in (2, 3, 4, 5, 6, 8, 10, 15, 20):
            lams = [offline_cusum(r["log"]["x_kpi"], rs, k, h, sigma) for r, rs in zip(cal_ro, resets)]
            fires = [simulate_trigger(l, 0.999) for l in lams]
            ms = [event_metrics(f, event_list(sp), T) for f, sp in zip(fires, specs)]
            f1 = np.mean([m["f1"] for m in ms]); fpr = np.mean([m["fpr"] for m in ms])
            scan.append({"k": k, "h": h, "f1": float(f1), "fpr": float(fpr)})
    ok = [s for s in scan if s["fpr"] <= 0.05] or scan
    bestc = max(ok, key=lambda s: s["f1"])
    log(f"CUSUM scan best: {bestc}")
    json.dump(scan, open(os.path.join(OUT, "cusum_scan.json"), "w"))
    lams = [offline_cusum(r["log"]["x_kpi"], rs, bestc["k"], bestc["h"], sigma) for r, rs in zip(cal_ro, resets)]
    S = [np.clip(r["log"]["s"], 1e-4, 1 - 1e-4) for r in cal_ro]
    Phi = [np.stack([np.log(s / (1 - s)), l, c, s * l], 1) for s, l, c in zip(S, lams, cps)]
    Yc = np.concatenate([r["y"] for r in cal_ro]); Pc = np.concatenate(Phi)
    calib = {"cusum_k": bestc["k"], "cusum_h": bestc["h"], "kpi_sigma": sigma.tolist(), "bocpd_hazard": 0.01, "bocpd_var": bvar}
    for fam, cols in (("sem", [0]), ("stat", [1, 2]), ("fusion", [0, 1, 2, 3])):
        w, b = fit_lr(Pc[:, cols], Yc)
        wf = np.zeros(4); wf[cols] = w
        P_list = [1 / (1 + np.exp(-(ph @ wf + b))) for ph in Phi]
        tau = pick_tau(P_list, specs, T)
        calib[fam] = {"w": wf.tolist(), "b": b, "tau": tau[0], "cal_f1": tau[1], "cal_prec": tau[2], "cal_rec": tau[3], "cal_fpr": tau[4]}
        log(f"calibrated {fam}: w={np.round(wf,3).tolist()} b={b:.3f} tau={tau[0]:.3f} F1={tau[1]:.3f} P={tau[2]:.3f} R={tau[3]:.3f} FPR={tau[4]:.3f}")
    # sensitivity data for E2 (+-20% perturbation of h and tau)
    json.dump(calib, open(os.path.join(OUT, "calib.json"), "w"), indent=1)
    pickle.dump({"cal_specs": specs, "sigma": sigma}, open(os.path.join(OUT, "calib_meta.pkl"), "wb"))
    log(f"done in {time.time()-t0:.0f}s")


if __name__ == "__main__":
    main()
